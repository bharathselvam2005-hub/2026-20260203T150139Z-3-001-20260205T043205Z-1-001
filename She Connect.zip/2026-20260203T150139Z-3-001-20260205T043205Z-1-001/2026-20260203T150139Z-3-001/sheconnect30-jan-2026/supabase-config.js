
if (typeof window.supabaseClient === 'undefined') {
    const SUPABASE_URL = 'https://hqmrjamyspugecbbuwvn.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhxbXJqYW15c3B1Z2VjYmJ1d3ZuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg4MjYwNDUsImV4cCI6MjA4NDQwMjA0NX0.TlhjwgbpfQrzxqgVQcFKYX6J9hYmN6MD8Menurx57zM';
    // Check if supabase is already declared globally
    // Initialize Supabase client
    let supabase = null;
    
    try {
        if (window.supabase) {
            supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
                realtime: {
                    params: {
                        eventsPerSecond: 10
                    }
                }
            });
            console.log('Supabase client initialized successfully');
        } else {
            console.error('Supabase JS library not loaded');
        }
    } catch (error) {
        console.error('Failed to initialize Supabase client:', error);
        supabase = null;
    }

    // Export for use in other files
    window.supabaseClient = supabase;

    // Test connection
    if (supabase) {
        supabase.auth.getSession().then(({ data, error }) => {
            if (error) {
                console.log('Supabase auth test failed:', error.message);
            } else {
                console.log('Supabase connection test successful');
            }
        }).catch(error => {
            console.log('Supabase connection test error:', error);
        });
    }
} else {
    console.log('Supabase client already initialized');
}