// Business State Management with Supabase Integration
class BusinessState {
    constructor() {
        this.currentUser = null;
        this.isLoggedIn = false;
        this.currentCategory = 'all';
        this.currentChatWith = null;
        this.chatMessages = [];
        this.isCallActive = false;
        this.isTyping = false;
        this.registrationStep = 1;
        this.selectedCategories = [];
        this.userProductsServices = [];
        this.uploadedMedia = [];
        this.businessMetrics = this.getDefaultMetrics();
        this.entrepreneurs = [];
        this.realtimeSubscriptions = [];
        this.orders = [];
        this.notifications = [];
        this.events = [];
        this.categories = [];
        this.connections = [];
        this.conversations = [];
    }

    getDefaultMetrics() {
        return {
            credit_score: 500,
            total_credit: 0,
            available_credit: 0,
            connections_count: 0,
            active_connections: 0,
            collaborations_count: 0,
            successful_collaborations: 0,
            value_added: 0,
            monthly_revenue: 0,
            quarterly_revenue: 0,
            annual_revenue: 0,
            profit_margin: 0,
            active_projects: 0,
            completed_projects: 0,
            client_retention_rate: 0,
            order_volume: 0,
            order_value: 0,
            growth_rate: 0,
            total_revenue: 0,
            partner_value_add: 0,
            business_growth: 0,
            social_impact_score: 0
        };
    }

    // Clear all realtime subscriptions
    clearSubscriptions() {
        this.realtimeSubscriptions.forEach(subscription => {
            if (subscription) subscription.unsubscribe();
        });
        this.realtimeSubscriptions = [];
    }
}

// Main Application Controller with Full Supabase Integration
class SheConnectApp {
    constructor() {
        this.state = new BusinessState();
        this.supabase = window.supabaseClient || null;
        this.profileSections = null;
        this.init();
    }


    async init() {
        await this.initializeSupabase();
        this.loadFromLocalStorage();
        this.setupEventListeners();
        this.setupChat();
        this.showWelcomeNotification();

        // Load initial data if logged in
        if (this.state.isLoggedIn) {
            await this.loadInitialData();
            this.setupRealtimeSubscriptions();
            this.setupProfileImageUpload();
        }
        this.initProfileSections();
    }
    initProfileSections() {
        if (!window.profileSections) {
            this.profileSections = new ProfileSections(this);
            window.profileSections = this.profileSections;
        } else {
            this.profileSections = window.profileSections;
        }
    }
    // Initialize Supabase Connection
    async initializeSupabase() {
        try {
            this.showSupabaseStatus('connecting', 'Connecting to Supabase...');

            if (!this.supabase) {
                throw new Error('Supabase client not initialized');
            }

            // Test connection
            const { data, error } = await this.supabase.auth.getSession();

            if (error) {
                console.warn('Supabase auth error:', error.message);
            }

            this.showSupabaseStatus('connected', 'Connected to Supabase');

        } catch (error) {
            console.log('Supabase connection error:', error.message);
            this.showSupabaseStatus('error', 'Connection failed');
        }
    }

    // Load initial data from Supabase
    async loadInitialData() {
        if (!this.supabase || !this.state.isLoggedIn) return;

        try {
            // Load categories
            const { data: categories, error: categoriesError } = await this.supabase
                .from('categories')
                .select('*')
                .eq('is_active', true)
                .order('display_order', { ascending: true });

            if (!categoriesError && categories) {
                this.state.categories = categories;
            }

            // Load entrepreneurs
            await this.loadEntrepreneursFromSupabase();

            // Load user products/services
            await this.loadProductsFromSupabase();

            // Load user connections
            await this.loadConnectionsFromSupabase();

            // Load user metrics
            await this.loadBusinessMetricsFromSupabase();

            // Load messages
            await this.loadMessagesFromSupabase();

            // Load orders
            await this.loadOrdersFromSupabase();

            // Load events
            await this.loadEventsFromSupabase();

            // Load notifications
            await this.loadNotificationsFromSupabase();

        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }

    // Setup real-time subscriptions
    setupRealtimeSubscriptions() {
        if (!this.supabase || !this.state.isLoggedIn) return;

        console.log('Setting up real-time subscriptions...');

        // 1. Entrepreneurs subscription
        const entrepreneursChannel = this.supabase
            .channel('entrepreneurs-channel')
            .on(
                'postgres_changes',
                {
                    event: '*',
                    schema: 'public',
                    table: 'entrepreneurs'
                },
                (payload) => {
                    console.log('Entrepreneurs change:', payload);
                    this.handleEntrepreneursChange(payload);
                }
            )
            .subscribe();

        this.state.realtimeSubscriptions.push(entrepreneursChannel);

        // 2. Messages subscription
        const messagesChannel = this.supabase
            .channel('messages-channel')
            .on(
                'postgres_changes',
                {
                    event: 'INSERT',
                    schema: 'public',
                    table: 'chat_messages',
                    filter: `or(receiver_id.eq.${this.state.currentUser.id},sender_id.eq.${this.state.currentUser.id})`
                },
                (payload) => {
                    console.log('New message:', payload);
                    this.handleNewMessage(payload.new);
                }
            )
            .subscribe();

        this.state.realtimeSubscriptions.push(messagesChannel);

        // 3. Connections subscription
        const connectionsChannel = this.supabase
            .channel('connections-channel')
            .on(
                'postgres_changes',
                {
                    event: '*',
                    schema: 'public',
                    table: 'connections',
                    filter: `or(user_id.eq.${this.state.currentUser.id},entrepreneur_id.eq.${this.state.currentUser.id})`
                },
                (payload) => {
                    console.log('Connections change:', payload);
                    this.handleConnectionsChange(payload);
                }
            )
            .subscribe();

        this.state.realtimeSubscriptions.push(connectionsChannel);

        // 4. Products/Services subscription
        const productsChannel = this.supabase
            .channel('products-channel')
            .on(
                'postgres_changes',
                {
                    event: '*',
                    schema: 'public',
                    table: 'products_services',
                    filter: `user_id.eq.${this.state.currentUser.id}`
                },
                (payload) => {
                    console.log('Products change:', payload);
                    this.handleProductsChange(payload);
                }
            )
            .subscribe();

        this.state.realtimeSubscriptions.push(productsChannel);

        // 5. Orders subscription
        const ordersChannel = this.supabase
            .channel('orders-channel')
            .on(
                'postgres_changes',
                {
                    event: '*',
                    schema: 'public',
                    table: 'orders',
                    filter: `or(buyer_id.eq.${this.state.currentUser.id},seller_id.eq.${this.state.currentUser.id})`
                },
                (payload) => {
                    console.log('Orders change:', payload);
                    this.handleOrdersChange(payload);
                }
            )
            .subscribe();

        this.state.realtimeSubscriptions.push(ordersChannel);

        // 6. Notifications subscription
        const notificationsChannel = this.supabase
            .channel('notifications-channel')
            .on(
                'postgres_changes',
                {
                    event: 'INSERT',
                    schema: 'public',
                    table: 'notifications',
                    filter: `user_id.eq.${this.state.currentUser.id}`
                },
                (payload) => {
                    console.log('New notification:', payload);
                    this.handleNewNotification(payload.new);
                }
            )
            .subscribe();

        this.state.realtimeSubscriptions.push(notificationsChannel);

        console.log('All real-time subscriptions set up');
    }

    // ============ REALTIME HANDLERS ============

    async handleEntrepreneursChange(payload) {
        console.log('Processing entrepreneurs change:', payload);

        try {
            // Refresh entrepreneurs list
            await this.loadEntrepreneursFromSupabase();

            // Update UI if on networking page
            if (document.getElementById('networkingPage').classList.contains('active')) {
                this.loadEntrepreneurs();
                this.showNotification('Network updated', 'info');
            }
        } catch (error) {
            console.error('Error handling entrepreneurs change:', error);
        }
    }

    async handleNewMessage(payload) {
        console.log('Processing new message:', payload);

        try {
            // Add to state
            const newMessage = {
                id: payload.id,
                conversation_id: payload.conversation_id,
                sender_id: payload.sender_id,
                receiver_id: payload.receiver_id,
                sender_type: payload.sender_type,
                message: payload.message,
                created_at: payload.created_at,
                is_read: payload.is_read,
                sender_name: payload.sender_id === this.state.currentUser.id ? 'You' : 'Unknown'
            };

            // Update conversations
            const convIndex = this.state.conversations.findIndex(c => c.conversation_id === payload.conversation_id);
            if (convIndex === -1) {
                await this.loadConversationsFromSupabase();
            } else {
                this.state.conversations[convIndex].last_message_at = payload.created_at;
                this.state.conversations[convIndex].last_message = payload.message;
                this.state.conversations.sort((a, b) => new Date(b.last_message_at) - new Date(a.last_message_at));
            }

            // Update UI
            if (document.getElementById('messagesPage').classList.contains('active')) {
                await this.loadMessagesFromSupabase();
                this.loadConversations();
            }

            // Show notification if message is for current user
            if (payload.receiver_id === this.state.currentUser.id) {
                const senderName = await this.getUserName(payload.sender_id);
                this.showNotification(`New message from ${senderName}`, 'info');

                // Desktop notification
                if ('Notification' in window && Notification.permission === 'granted') {
                    new Notification(`New message from ${senderName}`, {
                        body: payload.message,
                        icon: '/favicon.ico'
                    });
                }
            }
        } catch (error) {
            console.error('Error handling new message:', error);
        }
    }

    async handleConnectionsChange(payload) {
        console.log('Processing connections change:', payload);

        try {
            // Refresh connections
            await this.loadConnectionsFromSupabase();

            // Refresh entrepreneurs with updated connection status
            await this.loadEntrepreneursFromSupabase();

            // Update business metrics if connection was accepted
            if (payload.new && payload.new.status === 'accepted' &&
                (payload.new.user_id === this.state.currentUser.id ||
                    payload.new.entrepreneur_id === this.state.currentUser.id)) {
                await this.updateBusinessMetricsAfterConnection();
            }

            // Update UI
            if (document.getElementById('networkingPage').classList.contains('active')) {
                this.loadEntrepreneurs();
            }

            if (document.getElementById('businessProfilePage').classList.contains('active')) {
                await this.loadBusinessMetricsFromSupabase();
                this.updateBusinessMetricsDisplay();
            }
        } catch (error) {
            console.error('Error handling connections change:', error);
        }
    }

    async handleProductsChange(payload) {
        console.log('Processing products change:', payload);

        try {
            // Refresh products
            await this.loadProductsFromSupabase();

            // Update UI
            if (document.getElementById('businessProfilePage').classList.contains('active')) {
                this.loadUserProductsServices();
                this.showNotification('Products updated', 'info');
            }
        } catch (error) {
            console.error('Error handling products change:', error);
        }
    }

    async handleOrdersChange(payload) {
        console.log('Processing orders change:', payload);

        try {
            // Refresh orders
            await this.loadOrdersFromSupabase();

            // Update business metrics if order status changed
            if (payload.new && payload.old && payload.new.status !== payload.old.status) {
                await this.loadBusinessMetricsFromSupabase();
                this.updateBusinessMetricsDisplay();
            }

            // Show notification for new orders
            if (payload.new && payload.eventType === 'INSERT') {
                this.showNotification(`New order received: ${payload.new.order_number}`, 'info');
            }
        } catch (error) {
            console.error('Error handling orders change:', error);
        }
    }

    async handleNewNotification(payload) {
        console.log('Processing new notification:', payload);

        try {
            // Add to state
            this.state.notifications.unshift(payload);

            // Keep only last 50 notifications
            if (this.state.notifications.length > 50) {
                this.state.notifications = this.state.notifications.slice(0, 50);
            }

            // Show notification
            this.showNotification(payload.message, 'info');

        } catch (error) {
            console.error('Error handling new notification:', error);
        }
    }

    // ============ SUPABASE DATA LOADING ============

    async loadEntrepreneursFromSupabase() {
        if (!this.supabase) return;

        try {
            console.log('Loading users from Supabase...');

            // Fetch from 'users' table instead of 'entrepreneurs'
            const { data: users, error } = await this.supabase
                .from('users')
                .select('*')
                .eq('is_active', true)
                .neq('id', this.state.currentUser?.id) // Exclude current user
                .order('created_at', { ascending: false });

            if (error) {
                console.error('Error loading users:', error);
                return;
            }

            if (users) {
                // Load connections to get status
                const { data: connections } = await this.supabase
                    .from('connections')
                    .select('entrepreneur_id, status')
                    .eq('user_id', this.state.currentUser?.id);

                const connectionMap = {};
                if (connections) {
                    connections.forEach(conn => {
                        connectionMap[conn.entrepreneur_id] = conn.status;
                    });
                }

                // Map users to the format expected by NetworkCategories
                this.state.entrepreneurs = users.map(user => ({
                    id: user.id,
                    name: user.full_name,
                    business_name: user.business_name,
                    category: user.business_category?.toLowerCase() || 'other',
                    location: user.location || 'Not Specified',
                    description: user.bio || `Entrepreneur in ${user.business_category}`,
                    avatar: user.full_name ? user.full_name.charAt(0).toUpperCase() : 'U',
                    yearsInBusiness: user.years_in_business || 0,
                    rating: 5.0, // Default rating as users table might not have it
                    connections: 0, // Default connections
                    products: [], // Placeholder
                    connectionStatus: connectionMap[user.id] || 'none'
                }));

                console.log(`Loaded ${this.state.entrepreneurs.length} users`);

                // Update NetworkCategories if it exists
                if (window.networkCategories) {
                    window.networkCategories.setUsers(this.state.entrepreneurs);
                }
            }
        } catch (error) {
            console.error('Error in loadEntrepreneursFromSupabase:', error);
        }
    }

    async loadConnectionsFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            const { data: connections, error } = await this.supabase
                .from('connections')
                .select(`
                    *,
                    entrepreneurs:entrepreneur_id (*),
                    users:user_id (*)
                `)
                .or(`user_id.eq.${this.state.currentUser.id},entrepreneur_id.eq.${this.state.currentUser.id}`);

            if (!error && connections) {
                this.state.connections = connections;
            }
        } catch (error) {
            console.error('Error loading connections:', error);
        }
    }

    async loadProductsFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            const { data: products, error } = await this.supabase
                .from('products_services')
                .select('*')
                .eq('user_id', this.state.currentUser.id)
                .order('created_at', { ascending: false });

            if (!error && products) {
                this.state.userProductsServices = products;
            }
        } catch (error) {
            console.error('Error loading products:', error);
        }
    }

    async loadBusinessMetricsFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            const { data: metrics, error } = await this.supabase
                .from('business_metrics')
                .select('*')
                .eq('user_id', this.state.currentUser.id)
                .single();

            if (!error && metrics) {
                this.state.businessMetrics = metrics;
            }
        } catch (error) {
            console.error('Error loading business metrics:', error);
        }
    }

    async loadMessagesFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            // Load conversations instead of individual messages
            await this.loadConversationsFromSupabase();
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }

    async loadConversationsFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            const { data: messages, error } = await this.supabase
                .from('chat_messages')
                .select('*')
                .or(`sender_id.eq.${this.state.currentUser.id},receiver_id.eq.${this.state.currentUser.id}`)
                .order('created_at', { ascending: false });

            if (!error && messages) {
                // Group by conversation
                const conversations = {};
                messages.forEach(msg => {
                    const otherId = msg.sender_id === this.state.currentUser.id ? msg.receiver_id : msg.sender_id;
                    const otherType = msg.sender_id === this.state.currentUser.id ? msg.receiver_type : msg.sender_type;

                    if (!conversations[otherId]) {
                        conversations[otherId] = {
                            conversation_id: msg.conversation_id,
                            other_id: otherId,
                            other_type: otherType,
                            last_message: msg.message,
                            last_message_at: msg.created_at,
                            unread_count: 0,
                            messages: []
                        };
                    }

                    conversations[otherId].messages.push(msg);

                    if (msg.receiver_id === this.state.currentUser.id && !msg.is_read) {
                        conversations[otherId].unread_count++;
                    }

                    // Keep only the latest message time
                    if (new Date(msg.created_at) > new Date(conversations[otherId].last_message_at)) {
                        conversations[otherId].last_message = msg.message;
                        conversations[otherId].last_message_at = msg.created_at;
                    }
                });

                this.state.conversations = Object.values(conversations).sort((a, b) =>
                    new Date(b.last_message_at) - new Date(a.last_message_at)
                );
            }
        } catch (error) {
            console.error('Error loading conversations:', error);
        }
    }

    async loadOrdersFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            const { data: orders, error } = await this.supabase
                .from('orders')
                .select(`
                    *,
                    buyer:buyer_id (*),
                    seller:seller_id (*),
                    product:product_service_id (*)
                `)
                .or(`buyer_id.eq.${this.state.currentUser.id},seller_id.eq.${this.state.currentUser.id}`)
                .order('created_at', { ascending: false });

            if (!error && orders) {
                this.state.orders = orders;
            }
        } catch (error) {
            console.error('Error loading orders:', error);
        }
    }

    async loadEventsFromSupabase() {
        if (!this.supabase) return;

        try {
            const { data: events, error } = await this.supabase
                .from('events')
                .select('*')
                .eq('is_active', true)
                .gte('start_time', new Date().toISOString())
                .order('start_time', { ascending: true });

            if (!error && events) {
                this.state.events = events;
            }
        } catch (error) {
            console.error('Error loading events:', error);
        }
    }

    async loadNotificationsFromSupabase() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            const { data: notifications, error } = await this.supabase
                .from('notifications')
                .select('*')
                .eq('user_id', this.state.currentUser.id)
                .order('created_at', { ascending: false })
                .limit(20);

            if (!error && notifications) {
                this.state.notifications = notifications;
            }
        } catch (error) {
            console.error('Error loading notifications:', error);
        }
    }

    // ============ SUPABASE DATA SAVING ============

    async saveUserToSupabase(userData) {
        if (!this.supabase) return null;

        try {
            // Create auth user
            const { data: authData, error: authError } = await this.supabase.auth.signUp({
                email: userData.email,
                password: userData.password,
                options: {
                    data: {
                        full_name: userData.name,
                        business_name: userData.businessName
                    }
                }
            });

            if (authError) throw authError;

            // Create user in users table
            const { data: user, error: userError } = await this.supabase
                .from('users')
                .insert([{
                    id: authData.user.id,
                    email: userData.email,
                    full_name: userData.name,
                    phone: userData.phone,
                    location: userData.location,
                    business_name: userData.businessName,
                    business_category: userData.businessCategory,
                    additional_categories: userData.additionalCategories || [],
                    years_in_business: parseInt(userData.yearsInBusiness),
                    is_verified: false,
                    is_active: true
                }])
                .select()
                .single();

            if (userError) throw userError;

            // Create business metrics
            const baseCredit = 50000 * (parseInt(userData.yearsInBusiness) || 1);
            const randomFactor = 0.3 + Math.random() * 0.7;

            const { error: metricsError } = await this.supabase
                .from('business_metrics')
                .insert([{
                    user_id: user.id,
                    credit_score: 500 + ((parseInt(userData.yearsInBusiness) || 1) * 10),
                    total_credit: baseCredit,
                    available_credit: baseCredit * 0.8,
                    connections_count: Math.min(3 * (parseInt(userData.yearsInBusiness) || 1) + Math.floor(Math.random() * 10), 50),
                    collaborations_count: Math.min(2 * (parseInt(userData.yearsInBusiness) || 1) + Math.floor(Math.random() * 5), 30),
                    monthly_revenue: baseCredit / ((parseInt(userData.yearsInBusiness) || 1) * 12) * (0.8 + Math.random() * 0.4),
                    profit_margin: 15 + Math.random() * 30,
                    active_projects: 1 + Math.floor(Math.random() * 5) + (parseInt(userData.yearsInBusiness) || 1),
                    client_retention_rate: 70 + Math.random() * 25,
                    order_volume: 10 * (parseInt(userData.yearsInBusiness) || 1) + Math.floor(Math.random() * 20),
                    growth_rate: 10 + Math.random() * 40,
                    total_revenue: baseCredit * (1 + (parseInt(userData.yearsInBusiness) || 1) * 0.1)
                }]);

            if (metricsError) console.error('Metrics creation error:', metricsError);

            return user;

        } catch (error) {
            console.error('Error saving user to Supabase:', error);
            return null;
        }
    }

    async saveConnectionToSupabase(entrepreneurId, connectionNote = null) {
        if (!this.supabase || !this.state.currentUser) return false;

        try {
            const { data, error } = await this.supabase
                .from('connections')
                .insert([{
                    user_id: this.state.currentUser.id,
                    entrepreneur_id: entrepreneurId,
                    status: 'pending',
                    initiated_by: 'user',
                    connection_note: connectionNote
                }]);

            if (error) throw error;

            // Create notification for entrepreneur
            const entrepreneur = this.state.entrepreneurs.find(e => e.id === entrepreneurId);
            if (entrepreneur) {
                await this.createNotification(
                    entrepreneurId,
                    'Connection Request',
                    `${this.state.currentUser.full_name} wants to connect with you`,
                    'connection'
                );
            }

            return true;

        } catch (error) {
            console.error('Error saving connection:', error);
            return false;
        }
    }

    async updateConnectionStatus(connectionId, status) {
        if (!this.supabase) return false;

        try {
            const { data, error } = await this.supabase
                .from('connections')
                .update({
                    status: status,
                    connected_at: status === 'accepted' ? new Date().toISOString() : null,
                    updated_at: new Date().toISOString()
                })
                .eq('id', connectionId);

            if (error) throw error;

            // Update business metrics if connection accepted
            if (status === 'accepted') {
                await this.updateBusinessMetricsAfterConnection();
            }

            return true;

        } catch (error) {
            console.error('Error updating connection:', error);
            return false;
        }
    }

    async saveProductToSupabase(productData) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            const { data, error } = await this.supabase
                .from('products_services')
                .insert([{
                    user_id: this.state.currentUser.id,
                    name: productData.name,
                    description: productData.description,
                    price: productData.price,
                    currency: 'INR',
                    type: productData.type,
                    category: productData.category,
                    subcategory: productData.subcategory,
                    tags: productData.tags || [],
                    images: productData.images || [],
                    videos: productData.videos || [],
                    specifications: productData.specifications || {},
                    availability: productData.availability || 'in_stock',
                    stock_quantity: productData.stock_quantity || 0,
                    minimum_order: productData.minimum_order || 1,
                    lead_time_days: productData.lead_time_days || 7,
                    is_customizable: productData.is_customizable || false,
                    available_for_collab: productData.available_for_collab || true,
                    is_featured: false,
                    is_active: true
                }])
                .select()
                .single();

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('Error saving product:', error);
            return null;
        }
    }

    async updateProductInSupabase(productId, productData) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            const { data, error } = await this.supabase
                .from('products_services')
                .update(productData)
                .eq('id', productId)
                .eq('user_id', this.state.currentUser.id)
                .select()
                .single();

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('Error updating product:', error);
            return null;
        }
    }

    async deleteProductFromSupabase(productId) {
        if (!this.supabase || !this.state.currentUser) return false;

        try {
            const { error } = await this.supabase
                .from('products_services')
                .delete()
                .eq('id', productId)
                .eq('user_id', this.state.currentUser.id);

            if (error) throw error;

            return true;

        } catch (error) {
            console.error('Error deleting product:', error);
            return false;
        }
    }

    async saveChatMessageToSupabase(message, receiverId, receiverType) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            // Generate conversation ID
            const conversationId = this.state.currentUser.id < receiverId ?
                `${this.state.currentUser.id}_${receiverId}` :
                `${receiverId}_${this.state.currentUser.id}`;

            const { data, error } = await this.supabase
                .from('chat_messages')
                .insert([{
                    conversation_id: conversationId,
                    sender_id: this.state.currentUser.id,
                    receiver_id: receiverId,
                    sender_type: 'user',
                    receiver_type: receiverType,
                    message_type: 'text',
                    message: message,
                    is_read: false,
                    delivered_at: new Date().toISOString()
                }])
                .select()
                .single();

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('Error saving chat message:', error);
            return null;
        }
    }

    async createOrder(orderData) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            const { data, error } = await this.supabase
                .from('orders')
                .insert([{
                    buyer_id: this.state.currentUser.id,
                    seller_id: orderData.seller_id,
                    product_service_id: orderData.product_service_id,
                    quantity: orderData.quantity || 1,
                    unit_price: orderData.unit_price,
                    total_amount: orderData.total_amount,
                    currency: 'INR',
                    status: 'pending',
                    payment_status: 'pending',
                    shipping_address: orderData.shipping_address,
                    billing_address: orderData.billing_address || orderData.shipping_address,
                    notes: orderData.notes
                }])
                .select()
                .single();

            if (error) throw error;

            // Update product order count
            await this.supabase
                .from('products_services')
                .update({
                    order_count: this.supabase.sql`order_count + 1`,
                    updated_at: new Date().toISOString()
                })
                .eq('id', orderData.product_service_id);

            // Update business metrics
            await this.updateBusinessMetricsAfterOrder(orderData.total_amount);

            // Create notification for seller
            await this.createNotification(
                orderData.seller_id,
                'New Order',
                `You have a new order from ${this.state.currentUser.full_name}`,
                'order'
            );

            return data;

        } catch (error) {
            console.error('Error creating order:', error);
            return null;
        }
    }

    async createNotification(userId, title, message, type = 'info', category = 'general') {
        if (!this.supabase) return null;

        try {
            const { data, error } = await this.supabase
                .from('notifications')
                .insert([{
                    user_id: userId,
                    title: title,
                    message: message,
                    type: type,
                    category: category,
                    is_read: false
                }]);

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('Error creating notification:', error);
            return null;
        }
    }

    async createReview(reviewData) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            const { data, error } = await this.supabase
                .from('reviews_ratings')
                .insert([{
                    reviewer_id: this.state.currentUser.id,
                    reviewed_id: reviewData.reviewed_id,
                    entity_type: reviewData.entity_type,
                    rating: reviewData.rating,
                    title: reviewData.title,
                    review: reviewData.review,
                    images: reviewData.images || [],
                    is_verified_purchase: reviewData.is_verified_purchase || false,
                    is_approved: false
                }])
                .select()
                .single();

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('Error creating review:', error);
            return null;
        }
    }

    async createMeeting(meetingData) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            const { data, error } = await this.supabase
                .from('meetings')
                .insert([{
                    title: meetingData.title,
                    description: meetingData.description,
                    organizer_id: this.state.currentUser.id,
                    participant_id: meetingData.participant_id,
                    meeting_type: meetingData.meeting_type || 'video',
                    platform: meetingData.platform || 'google_meet',
                    meeting_link: meetingData.meeting_link,
                    meeting_password: meetingData.meeting_password,
                    scheduled_for: meetingData.scheduled_for,
                    duration_minutes: meetingData.duration_minutes || 30,
                    status: 'scheduled',
                    agenda: meetingData.agenda
                }])
                .select()
                .single();

            if (error) throw error;

            // Create notification for participant
            await this.createNotification(
                meetingData.participant_id,
                'Meeting Scheduled',
                `${this.state.currentUser.full_name} scheduled a meeting with you`,
                'meeting'
            );

            return data;

        } catch (error) {
            console.error('Error creating meeting:', error);
            return null;
        }
    }

    async createPayment(paymentData) {
        if (!this.supabase || !this.state.currentUser) return null;

        try {
            const { data, error } = await this.supabase
                .from('payments')
                .insert([{
                    order_id: paymentData.order_id,
                    payer_id: this.state.currentUser.id,
                    receiver_id: paymentData.receiver_id,
                    amount: paymentData.amount,
                    currency: 'INR',
                    payment_method: paymentData.payment_method,
                    payment_gateway: paymentData.payment_gateway,
                    status: 'pending',
                    description: paymentData.description,
                    metadata: paymentData.metadata || {}
                }])
                .select()
                .single();

            if (error) throw error;

            return data;

        } catch (error) {
            console.error('Error creating payment:', error);
            return null;
        }
    }

    // ============ BUSINESS LOGIC FUNCTIONS ============

    async updateBusinessMetricsAfterConnection() {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            // Get current metrics
            const { data: metrics } = await this.supabase
                .from('business_metrics')
                .select('*')
                .eq('user_id', this.state.currentUser.id)
                .single();

            if (!metrics) return;

            // Update metrics
            const updatedMetrics = {
                connections_count: metrics.connections_count + 1,
                active_connections: metrics.active_connections + 1,
                updated_at: new Date().toISOString()
            };

            // Randomly increase other metrics
            if (Math.random() > 0.7) {
                updatedMetrics.collaborations_count = metrics.collaborations_count + 1;
                updatedMetrics.successful_collaborations = metrics.successful_collaborations + 1;
                updatedMetrics.value_added = metrics.value_added + (Math.random() * 5000);
            }

            // Update in database
            await this.supabase
                .from('business_metrics')
                .update(updatedMetrics)
                .eq('user_id', this.state.currentUser.id);

            // Update local state
            this.state.businessMetrics = { ...this.state.businessMetrics, ...updatedMetrics };

        } catch (error) {
            console.error('Error updating business metrics:', error);
        }
    }

    async updateBusinessMetricsAfterOrder(amount) {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            // Get current metrics
            const { data: metrics } = await this.supabase
                .from('business_metrics')
                .select('*')
                .eq('user_id', this.state.currentUser.id)
                .single();

            if (!metrics) return;

            // Update metrics
            const updatedMetrics = {
                order_volume: metrics.order_volume + 1,
                order_value: metrics.order_value + amount,
                monthly_revenue: metrics.monthly_revenue + (amount / 12),
                total_revenue: metrics.total_revenue + amount,
                updated_at: new Date().toISOString()
            };

            // Randomly increase growth
            if (Math.random() > 0.5) {
                updatedMetrics.growth_rate = Math.min(100, metrics.growth_rate + (Math.random() * 5));
                updatedMetrics.business_growth = Math.min(100, metrics.business_growth + (Math.random() * 3));
            }

            // Update in database
            await this.supabase
                .from('business_metrics')
                .update(updatedMetrics)
                .eq('user_id', this.state.currentUser.id);

            // Update local state
            this.state.businessMetrics = { ...this.state.businessMetrics, ...updatedMetrics };

        } catch (error) {
            console.error('Error updating business metrics after order:', error);
        }
    }

    async getUserName(userId) {
        if (!this.supabase) return 'User';

        try {
            // Check if it's a user
            const { data: user } = await this.supabase
                .from('users')
                .select('full_name')
                .eq('id', userId)
                .single();

            if (user) return user.full_name;

            // Check if it's an entrepreneur
            const { data: entrepreneur } = await this.supabase
                .from('entrepreneurs')
                .select('name')
                .eq('id', userId)
                .single();

            if (entrepreneur) return entrepreneur.name;

            return 'User';

        } catch (error) {
            console.error('Error getting user name:', error);
            return 'User';
        }
    }

    // ============ UI METHODS ============

    updateUIForLoggedInUser() {
        if (!this.state.currentUser) return;

        // Helper to get avatar HTML
        const getAvatarHTML = (user) => {
            if (user.avatar_url) {
                return `<img src="${user.avatar_url}" alt="${user.full_name}" onerror="this.parentElement.textContent='${user.full_name.charAt(0).toUpperCase()}'">`;
            }
            return user.full_name.charAt(0).toUpperCase();
        };

        // Update auth buttons
        const authButtons = document.getElementById('authButtons');
        if (authButtons) {
            authButtons.innerHTML = `
                <div class="user-profile" id="topNavProfile" title="Click to change profile picture">
                     <div class="user-avatar">${getAvatarHTML(this.state.currentUser)}</div>
                     <div class="user-name">${this.state.currentUser.full_name.split(' ')[0]}</div>
                </div>
            `;

            // Attach click listener for upload
            const topNavProfile = document.getElementById('topNavProfile');
            if (topNavProfile) {
                topNavProfile.addEventListener('click', () => {
                    document.getElementById('profileImageUpload').click();
                });
            }
        }

        // Update side navigation
        const sideNavUser = document.getElementById('sideNavUser');
        if (sideNavUser) {
            sideNavUser.style.display = 'flex';

            const sideNavUserAvatar = document.getElementById('sideNavUserAvatar');
            if (sideNavUserAvatar) sideNavUserAvatar.textContent =
                this.state.currentUser.full_name ? this.state.currentUser.full_name.charAt(0).toUpperCase() : 'U';

            const sideNavUserName = document.getElementById('sideNavUserName');
            if (sideNavUserName) sideNavUserName.textContent = this.state.currentUser.full_name || '';

            const sideNavUserBusiness = document.getElementById('sideNavUserBusiness');
            if (sideNavUserBusiness) sideNavUserBusiness.textContent = this.state.currentUser.business_name || '';

            const sideNavLogout = document.getElementById('sideNavLogout');
            if (sideNavLogout) sideNavLogout.style.display = 'block';

            const sideNavLogin = document.getElementById('sideNavLogin');
            if (sideNavLogin) sideNavLogin.style.display = 'none';
        }

        // Update profile
        const userNameDisplay = document.getElementById('userNameDisplay');
        const userBusinessDisplay = document.getElementById('userBusinessDisplay');
        const userAvatarLarge = document.getElementById('userAvatarLarge');
        if (userNameDisplay) userNameDisplay.textContent = this.state.currentUser.full_name || '';
        if (userBusinessDisplay) userBusinessDisplay.textContent = this.state.currentUser.business_name || '';
        if (userAvatarLarge) userAvatarLarge.textContent = this.state.currentUser.full_name ? this.state.currentUser.full_name.charAt(0).toUpperCase() : 'U';

    }

    updateUIForLoggedOutUser() {
        const authButtons = document.getElementById('authButtons');
        if (authButtons) {
            authButtons.innerHTML = `
                <button class="auth-btn register-btn" id="openRegister">
                    <i class="fas fa-user-plus"></i> Join
                </button>
                <button class="auth-btn login-btn" id="openLogin">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            `;
        }

        document.getElementById('sideNavUser').style.display = 'none';
        document.getElementById('sideNavLogout').style.display = 'none';
        document.getElementById('sideNavLogin').style.display = 'block';
    }

    updateBusinessMetricsDisplay() {
        const metrics = this.state.businessMetrics;

        // Update main stats
        this.updateElementText('businessCredit', `₹${Math.round(metrics.total_credit || 0).toLocaleString()}`);
        this.updateElementText('businessConnections', metrics.connections_count || 0);
        this.updateElementText('businessCollab', metrics.collaborations_count || 0);
        this.updateElementText('valueAdd', `₹${Math.round(metrics.value_added || 0).toLocaleString()}`);

        // Update performance metrics
        this.updateElementText('monthlyRevenue', `₹${Math.round(metrics.monthly_revenue || 0).toLocaleString()}`);
        this.updateElementText('profitMargin', `${Math.round(metrics.profit_margin || 0)}%`);
        this.updateElementText('activeProjects', metrics.active_projects || 0);
        this.updateElementText('clientRetention', `${Math.round(metrics.client_retention_rate || 0)}%`);
        this.updateElementText('orderVolume', metrics.order_volume || 0);
        this.updateElementText('growthRate', `${Math.round(metrics.growth_rate || 0)}%`);


    }

    updateElementText(id, text) {
        const element = document.getElementById(id);
        if (element) element.textContent = text;
    }

    // ============ AUTHENTICATION ============

    async handleLogin() {
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;

        if (!email || !password) {
            this.showNotification('Please enter both email and password', 'error');
            return;
        }

        if (!this.validateEmail(email)) {
            this.showNotification('Please enter a valid email address', 'error');
            return;
        }

        // Check if Supabase client is available
        if (!this.supabase) {
            this.showNotification('Authentication service not available. Please try again.', 'error');
            console.error('Supabase client not initialized');
            return;
        }

        this.showNotification('Logging you in...', 'info');
        console.log('Attempting login for:', email);

        try {
            // Sign in with Supabase
            const { data, error } = await this.supabase.auth.signInWithPassword({
                email: email,
                password: password
            });

            if (error) {
                console.error('Login error:', error);
                this.showNotification(error.message || 'Login failed. Please try again.', 'error');
                return;
            }

            console.log('Login successful:', data);

            if (!data.user) {
                this.showNotification('Login failed. No user data received.', 'error');
                return;
            }

            // Set current user
            this.state.currentUser = data.user;
            this.state.isLoggedIn = true;

            // Close the auth modal
            this.closeAuthModal();

            // Get user profile from database
            await this.loadUserProfile(data.user.id);

            // Initial UI Update
            if (this.state.isLoggedIn) {
                this.updateUIForLoggedInUser();
                this.loadInitialData();
                this.setupProfileImageUpload(); // Setup upload listener
            } else {
                this.updateUIForLoggedOutUser();
            }
            this.updateBusinessProfile();

            // Show success message
            this.showNotification(`Welcome back, ${this.state.currentUser.full_name || data.user.email}!`, 'success');

            // Navigate to business page
            this.switchPage('business');

        } catch (error) {
            console.error('Unexpected login error:', error);
            this.showNotification('Login failed. Please try again.', 'error');
        }
    }

    handleMediaUpload(files) {
        const previewContainer = document.getElementById('mediaPreviewContainer');
        if (!previewContainer) return;

        Array.from(files).forEach(file => {
            if (file.size > 10 * 1024 * 1024) {
                this.showNotification(`File ${file.name} is too large (max 10MB)`, 'error');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const div = document.createElement('div');
                div.className = 'media-preview-item';

                let content = '';
                if (file.type.startsWith('image/')) {
                    content = `<img src="${e.target.result}" alt="Preview">`;
                } else if (file.type.startsWith('video/')) {
                    content = `<video src="${e.target.result}" controls></video>`;
                }

                div.innerHTML = `
                    ${content}
                    <button type="button" class="remove-media" onclick="this.parentElement.remove()">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                previewContainer.appendChild(div);
            };
            reader.readAsDataURL(file);
        });
    }

    setupProfileImageUpload() {
        const profileImageInput = document.getElementById('profileImageUpload');
        if (!profileImageInput) return;

        // Listener for file selection
        profileImageInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                this.handleProfileImageUpload(e.target.files[0]);
            }
        });
    }

    async handleProfileImageUpload(file) {
        if (!this.state.isLoggedIn || !this.supabase) return;

        // Validation
        if (!file.type.startsWith('image/')) {
            this.showNotification('Please upload an image file', 'error');
            return;
        }

        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            this.showNotification('Image size should be less than 5MB', 'error');
            return;
        }

        try {
            this.showNotification('Uploading profile picture...', 'info');

            const userId = this.state.currentUser.id;
            const timestamp = Date.now();
            const fileExt = file.name.split('.').pop();
            const fileName = `profile-pictures/${userId}/${timestamp}.${fileExt}`;

            // 1. Upload to Supabase Storage
            const { data: uploadData, error: uploadError } = await this.supabase.storage
                .from('sheconnect-media')
                .upload(fileName, file, {
                    cacheControl: '3600',
                    upsert: false
                });

            if (uploadError) throw uploadError;

            // 2. Get Public URL
            const { data: { publicUrl } } = this.supabase.storage
                .from('sheconnect-media')
                .getPublicUrl(fileName);

            // 3. Update User Profile in DB
            const { error: updateError } = await this.supabase
                .from('users')
                .update({ avatar_url: publicUrl })
                .eq('id', userId);

            if (updateError) throw updateError;

            // 4. Update Local State & UI
            this.state.currentUser.avatar_url = publicUrl;
            this.updateUIForLoggedInUser();
            this.updateBusinessProfile(); // In case it's used there too

            // Update profile page if open
            if (window.profileSections) {
                window.profileSections.updateUserInfo();
            }

            this.showNotification('Profile picture updated successfully!', 'success');

        } catch (error) {
            console.error('Error uploading profile picture:', error);

            let errorMessage = error.message || error.error_description || 'Unknown error';

            // Check for specific bucket error
            if (errorMessage.includes('Bucket not found') || (error.statusCode === '404' && errorMessage.includes('Bucket'))) {
                errorMessage = "Supabase Storage Bucket 'sheconnect-media' not found. Please create a public bucket named 'sheconnect-media' in your Supabase project dashboard.";
            }

            this.showNotification(`Failed to upload: ${errorMessage}`, 'error');
        }
    }

    async loadUserProfile(userId) {
        try {
            const { data: user, error: userError } = await this.supabase
                .from('users')
                .select('*')
                .eq('id', userId)
                .single();

            if (userError) {
                console.warn('User profile not found:', userError);
                // Use auth user data if profile doesn't exist
                this.state.currentUser = {
                    ...this.state.currentUser,
                    full_name: this.state.currentUser.user_metadata?.full_name || 'User'
                };
            } else {
                this.state.currentUser = { ...this.state.currentUser, ...user };
            }
        } catch (error) {
            console.error('Error loading user profile:', error);
        }
    }

    async handleRegistration() {
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const terms = document.getElementById('terms').checked;

        // Validation
        if (!terms) {
            this.showNotification('You must agree to the Terms of Service and Privacy Policy', 'error');
            return;
        }

        if (password !== confirmPassword) {
            this.showNotification('Passwords do not match', 'error');
            return;
        }

        if (password.length < 8) {
            this.showNotification('Password must be at least 8 characters long', 'error');
            return;
        }

        // Get form data
        const businessCategory = document.getElementById('businessCategory').value;
        let finalCategory = businessCategory;

        if (businessCategory === 'other') {
            finalCategory = document.getElementById('customCategory').value || 'Other';
        }

        const userData = {
            name: document.getElementById('fullName').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            location: document.getElementById('location').value,
            businessName: document.getElementById('businessName').value,
            businessCategory: finalCategory,
            additionalCategories: this.state.selectedCategories,
            yearsInBusiness: document.getElementById('yearsInBusiness').value,
            password: password
        };

        this.showNotification('Creating your account...', 'info');

        // Save to Supabase
        const supabaseUser = await this.saveUserToSupabase(userData);

        if (!supabaseUser) {
            this.showNotification('Account creation failed. Please try again.', 'error');
            return;
        }

        this.state.currentUser = supabaseUser;
        this.state.isLoggedIn = true;

        // Load initial data
        await this.loadInitialData();

        // Setup realtime subscriptions
        this.setupRealtimeSubscriptions();

        // Update UI
        this.updateUIForLoggedInUser();
        this.closeAuthModal();

        // Update business profile
        this.updateBusinessProfile();

        this.showNotification('Account created successfully! Welcome to SheConnect!', 'success');
        this.switchPage('business');
    }

    async handleLogout() {
        // Clear realtime subscriptions
        this.state.clearSubscriptions();

        // Sign out from Supabase
        if (this.supabase) {
            await this.supabase.auth.signOut();
        }

        // Clear state
        this.state.currentUser = null;
        this.state.isLoggedIn = false;
        this.state.entrepreneurs = [];
        this.state.connections = [];
        this.state.userProductsServices = [];
        this.state.conversations = [];
        this.state.orders = [];
        this.state.notifications = [];
        this.state.events = [];

        // Remove from localStorage
        localStorage.removeItem('sheConnectUser');

        // Update UI
        this.updateUIForLoggedOutUser();

        // Show notification
        this.showNotification('Logged out successfully', 'info');

        // Go to home page
        this.switchPage('home');
    }

    // ============ PAGE LOADING ============

    async loadPageData(page) {
        if (!this.state.isLoggedIn) return;

        try {
            switch (page) {
                case 'networking':
                    await this.loadEntrepreneursFromSupabase();
                    this.loadEntrepreneurs();
                    break;

                case 'messages':
                    await this.loadConversationsFromSupabase();
                    this.loadConversations();
                    break;

                case 'business':
                    await this.loadProductsFromSupabase();
                    await this.loadBusinessMetricsFromSupabase();
                    this.updateBusinessProfile();
                    this.loadUserProductsServices();
                    this.updateBusinessMetricsDisplay();
                    break;

                case 'profile':
                    // Profile data is already loaded
                    break;
            }
        } catch (error) {
            console.error(`Error loading ${page} data:`, error);
        }
    }

    // ============ EVENT LISTENERS SETUP ============

    setupEventListeners() {
        // Navigation
        this.addClickListener('hamburgerMenu', () => this.openSideNav());
        this.addClickListener('closeSideNav', () => this.closeSideNav());
        this.addClickListener('sideNavOverlay', () => this.closeSideNav());

        // Auth
        this.addClickListener('openRegister', () => this.openAuthModal('register'));
        this.addClickListener('openLogin', () => this.openAuthModal('login'));
        this.addClickListener('closeModal', () => this.closeAuthModal());

        // Pages
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.getAttribute('data-page');
                this.switchPage(page);
            });
        });

        // Side navigation
        document.querySelectorAll('.category-item[data-page]').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.getAttribute('data-page');
                this.closeSideNav();
                this.switchPage(page);
            });
        });

        // Side navigation buttons
        this.addClickListener('sideNavSettings', () => {
            this.closeSideNav();
            this.switchPage('profile');
        });

        this.addClickListener('sideNavHelp', () => {
            this.closeSideNav();
            this.showNotification('Help & Support feature coming soon!', 'info');
        });

        this.addClickListener('sideNavLogin', () => {
            this.closeSideNav();
            this.openAuthModal('register');
        });

        this.addClickListener('sideNavLogout', () => {
            this.closeSideNav();
            this.handleLogout();
        });

        // Feature buttons
        this.addClickListener('startProfile', (e) => {
            e.preventDefault();
            if (!this.state.isLoggedIn) {
                this.showNotification('Please login to create your business profile', 'info');
                this.openAuthModal('register');
            } else {
                this.switchPage('business');
                this.showNotification('Navigating to your business profile', 'info');
            }
        });

        this.addClickListener('connectEnt', (e) => {
            e.preventDefault();
            if (!this.state.isLoggedIn) {
                this.showNotification('Please login to connect with entrepreneurs', 'info');
                this.openAuthModal('register');
            } else {
                this.switchPage('networking');
                this.showNotification('Exploring entrepreneurs network', 'info');
            }
        });

        this.addClickListener('startChat', (e) => {
            e.preventDefault();
            if (!this.state.isLoggedIn) {
                this.showNotification('Please login to start chatting', 'info');
                this.openAuthModal('register');
            } else {
                this.switchPage('messages');
                this.showNotification('Opening your messages', 'info');
            }
        });

        // Quick actions
        this.addClickListener('quickNetwork', () => {
            if (!this.state.isLoggedIn) {
                this.showNotification('Please login to find businesses', 'info');
                this.openAuthModal('register');
            } else {
                this.switchPage('networking');
                this.showNotification('Finding businesses in your network', 'info');
            }
        });

        this.addClickListener('quickEvents', () => {
            this.showNotification('Events feature coming soon!', 'info');
        });

        this.addClickListener('quickResources', () => {
            this.showNotification('Resources feature coming soon!', 'info');
        });

        // Logout
        this.addClickListener('logoutBtn', () => this.handleLogout());

        // Business profile
        this.addClickListener('editBusinessInfo', () => {
            this.showNotification('Edit business information feature coming soon!', 'info');
        });

        this.addClickListener('performanceAnalytics', () => {
            this.showNotification('Performance analytics feature coming soon!', 'info');
        });

        this.addClickListener('addProductBtn', () => this.openProductForm());

        this.addClickListener('viewMilestones', () => {
            this.showNotification('View milestones feature coming soon!', 'info');
        });

        // Chat
        this.addClickListener('sendMessageBtn', () => this.sendMessage());
        this.addClickListener('closeChat', () => this.closeChat());

        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const filter = btn.getAttribute('data-filter');
                this.handleFilterClick(filter, btn);
            });
        });

        // Search
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.filterEntrepreneursBySearch(e.target.value);
            });
        }

        // Modal tabs
        this.addClickListener('loginTabBtn', () => this.switchAuthTab('login'));
        this.addClickListener('registerTabBtn', () => this.switchAuthTab('register'));

        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // Registration form navigation
        this.addClickListener('nextToStep2', () => this.goToStep2());
        this.addClickListener('backToStep1', () => this.goToStep1());
        this.addClickListener('nextToStep3', () => this.goToStep3());
        this.addClickListener('backToStep2', () => this.goBackToStep2());
        this.addClickListener('nextToStep4', () => this.goToStep4());
        this.addClickListener('backToStep3', () => this.goBackToStep3());

        // Register button
        const registerBtn = document.getElementById('registerBtn');
        if (registerBtn) {
            registerBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleRegistration();
            });
        }

        // Password toggle
        this.addClickListener('toggleLoginPassword', () => {
            this.togglePasswordVisibility('loginPassword', 'toggleLoginPassword');
        });

        this.addClickListener('togglePassword', () => {
            this.togglePasswordVisibility('password', 'togglePassword');
        });

        // Forgot password
        this.addClickListener('forgotPasswordLink', (e) => {
            e.preventDefault();
            this.showNotification('Password reset feature coming soon!', 'info');
        });

        // Business category change
        const businessCategorySelect = document.getElementById('businessCategory');
        if (businessCategorySelect) {
            businessCategorySelect.addEventListener('change', () => {
                this.handleBusinessCategoryChange();
            });
        }

        // Category tags
        document.querySelectorAll('.category-tag').forEach(tag => {
            tag.addEventListener('click', () => {
                this.toggleCategorySelection(tag);
            });
        });

        // Years slider
        const yearsSlider = document.getElementById('yearsInBusiness');
        if (yearsSlider) {
            yearsSlider.addEventListener('input', (e) => {
                this.updateYearsValue(e.target.value);
            });
        }

        // Product form
        this.addClickListener('closeProductForm', () => this.closeProductForm());
        this.addClickListener('cancelProductForm', () => this.closeProductForm());

        const productServiceForm = document.getElementById('productServiceForm');
        if (productServiceForm) {
            productServiceForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleProductServiceSubmit();
            });
        }

        // Media upload
        const mediaUploadArea = document.getElementById('mediaUploadArea');
        if (mediaUploadArea) {
            mediaUploadArea.addEventListener('click', () => {
                document.getElementById('mediaUpload').click();
            });
        }

        const mediaUploadInput = document.getElementById('mediaUpload');
        if (mediaUploadInput) {
            mediaUploadInput.addEventListener('change', (e) => {
                this.handleMediaUpload(e.target.files);
            });
        }

        // Chat features
        this.addClickListener('audioCallBtn', () => this.initiateCall('audio'));
        this.addClickListener('videoCallBtn', () => this.initiateCall('video'));
        this.addClickListener('meetBtn', () => this.initiateMeeting('google-meet'));
        this.addClickListener('zoomBtn', () => this.initiateMeeting('zoom'));
        this.addClickListener('teamsBtn', () => this.initiateMeeting('teams'));
        this.addClickListener('paymentBtn', () => this.openPaymentInterface());
        this.addClickListener('orderBtn', () => this.placeOrder());
        this.addClickListener('closeChatBtn', () => this.closeChat());

        // Call controls
        this.addClickListener('acceptCall', () => this.acceptCall());
        this.addClickListener('rejectCall', () => this.rejectCall());
        this.addClickListener('endCall', () => this.endCall());

        // Payment methods
        document.querySelectorAll('.payment-method').forEach(method => {
            method.addEventListener('click', () => {
                this.selectPaymentMethod(method);
            });
        });

        this.addClickListener('payNowBtn', () => this.processPayment());
        this.addClickListener('cancelPayment', () => this.closePaymentInterface());
    }

    addClickListener(id, handler) {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('click', handler);
        }
    }

    // ============ HELPER METHODS ============

    showNotification(message, type = 'info') {
        const notification = document.getElementById('notification');
        if (!notification) return;

        notification.textContent = message;
        notification.className = 'notification';

        switch (type) {
            case 'error':
                notification.style.background = '#e63946';
                notification.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
                break;
            case 'success':
                notification.style.background = '#4caf50';
                notification.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
                break;
            default:
                notification.style.background = 'linear-gradient(135deg, #d63384 0%, #9c3587 100%)';
                notification.innerHTML = `<i class="fas fa-info-circle"></i> ${message}`;
        }

        notification.classList.add('show');

        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    showSupabaseStatus(status, message) {
        const statusEl = document.getElementById('supabaseStatus');
        if (!statusEl) return;

        statusEl.textContent = message;
        statusEl.className = 'supabase-status';

        switch (status) {
            case 'connected':
                statusEl.classList.add('show');
                break;
            case 'error':
                statusEl.classList.add('error', 'show');
                break;
            case 'connecting':
                statusEl.classList.add('connecting');
                break;
        }
    }

    showWelcomeNotification() {
        setTimeout(() => {
            this.showNotification('Welcome to SheConnect! Empowering women entrepreneurs.', 'info');
        }, 1000);
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // ============ REGISTRATION FORM METHODS ============

    goToStep2() {
        // Validate step 1
        const name = document.getElementById('fullName').value;
        const phone = document.getElementById('phone').value;
        const email = document.getElementById('email').value;
        const location = document.getElementById('location').value;

        if (!name || !phone || !email || !location) {
            this.showNotification('Please fill in all personal information fields', 'error');
            return;
        }

        if (!this.validateEmail(email)) {
            this.showNotification('Please enter a valid email address', 'error');
            return;
        }

        // Move to step 2
        document.getElementById('step1').classList.remove('active');
        document.getElementById('step1').classList.add('completed');
        document.getElementById('step2').classList.add('active');

        document.getElementById('step1Form').classList.remove('active');
        document.getElementById('step2Form').classList.add('active');

        this.state.registrationStep = 2;
    }

    goToStep1() {
        document.getElementById('step2').classList.remove('active');
        document.getElementById('step1').classList.add('active');
        document.getElementById('step1').classList.remove('completed');

        document.getElementById('step2Form').classList.remove('active');
        document.getElementById('step1Form').classList.add('active');

        this.state.registrationStep = 1;
    }

    goToStep3() {
        // Validate step 2
        const businessName = document.getElementById('businessName').value;
        const businessCategory = document.getElementById('businessCategory').value;

        if (!businessName || !businessCategory) {
            this.showNotification('Please fill in all business information fields', 'error');
            return;
        }

        // If "other" is selected, validate custom category
        if (businessCategory === 'other') {
            const customCategory = document.getElementById('customCategory').value;
            if (!customCategory) {
                this.showNotification('Please specify your business category', 'error');
                return;
            }
        }

        // Move to step 3
        document.getElementById('step2').classList.remove('active');
        document.getElementById('step2').classList.add('completed');
        document.getElementById('step3').classList.add('active');

        document.getElementById('step2Form').classList.remove('active');
        document.getElementById('step3Form').classList.add('active');

        this.state.registrationStep = 3;
    }

    goBackToStep2() {
        document.getElementById('step3').classList.remove('active');
        document.getElementById('step2').classList.add('active');
        document.getElementById('step2').classList.remove('completed');

        document.getElementById('step3Form').classList.remove('active');
        document.getElementById('step2Form').classList.add('active');

        this.state.registrationStep = 2;
    }

    goToStep4() {
        // Validate step 3
        const productServiceName = document.getElementById('productServiceName').value;
        const productServiceDescription = document.getElementById('productServiceDescription').value;

        if (!productServiceName || !productServiceDescription) {
            this.showNotification('Please fill in product/service information', 'error');
            return;
        }

        // Move to step 4
        document.getElementById('step3').classList.remove('active');
        document.getElementById('step3').classList.add('completed');
        document.getElementById('step4Form').classList.add('active');

        document.getElementById('step3Form').classList.remove('active');
        document.getElementById('step4Form').classList.add('active');

        this.state.registrationStep = 4;
    }

    goBackToStep3() {
        document.getElementById('step4Form').classList.remove('active');
        document.getElementById('step3').classList.add('active');
        document.getElementById('step3').classList.remove('completed');

        document.getElementById('step4Form').classList.remove('active');
        document.getElementById('step3Form').classList.add('active');

        this.state.registrationStep = 3;
    }

    resetRegistrationForm() {
        // Reset steps
        document.getElementById('step1').classList.add('active');
        document.getElementById('step1').classList.remove('completed');
        document.getElementById('step2').classList.remove('active', 'completed');
        document.getElementById('step3').classList.remove('active', 'completed');
        document.getElementById('step4Form').classList.remove('active', 'completed');

        // Reset forms
        document.getElementById('step1Form').classList.add('active');
        document.getElementById('step2Form').classList.remove('active');
        document.getElementById('step3Form').classList.remove('active');
        document.getElementById('step4Form').classList.remove('active');

        // Reset form values
        if (document.getElementById('loginForm')) document.getElementById('loginForm').reset();
        if (document.getElementById('personalForm')) document.getElementById('personalForm').reset();
        if (document.getElementById('businessForm')) document.getElementById('businessForm').reset();
        if (document.getElementById('productServicesForm')) document.getElementById('productServicesForm').reset();
        if (document.getElementById('accountForm')) document.getElementById('accountForm').reset();

        // Reset category tags
        document.querySelectorAll('.category-tag').forEach(tag => {
            tag.classList.remove('selected');
        });
        this.state.selectedCategories = [];

        // Reset years slider
        if (document.getElementById('yearsInBusiness')) {
            document.getElementById('yearsInBusiness').value = 1;
            document.getElementById('yearsValue').textContent = '1 year';
        }

        // Reset custom category
        document.getElementById('customCategoryInput').classList.remove('active');

        this.state.registrationStep = 1;
    }

    togglePasswordVisibility(inputId, buttonId) {
        const passwordField = document.getElementById(inputId);
        const button = document.getElementById(buttonId);
        if (!passwordField || !button) return;

        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);
        button.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash"></i>';
    }

    toggleCategorySelection(tag) {
        const category = tag.getAttribute('data-category');

        if (tag.classList.contains('selected')) {
            tag.classList.remove('selected');
            this.state.selectedCategories = this.state.selectedCategories.filter(cat => cat !== category);
        } else {
            tag.classList.add('selected');
            this.state.selectedCategories.push(category);
        }
    }

    updateYearsValue(value) {
        const yearsValue = document.getElementById('yearsValue');
        if (!yearsValue) return;

        yearsValue.textContent = value === "0" ? "Less than 1 year" :
            value === "1" ? "1 year" :
                `${value} years`;
    }

    handleBusinessCategoryChange() {
        const businessCategorySelect = document.getElementById('businessCategory');
        const customCategoryInput = document.getElementById('customCategoryInput');

        if (businessCategorySelect.value === 'other') {
            customCategoryInput.classList.add('active');
        } else {
            customCategoryInput.classList.remove('active');
        }
    }

    // ============ PAGE NAVIGATION ============

    switchPage(page) {
        // Hide all pages
        document.querySelectorAll('.page-section').forEach(section => {
            section.classList.remove('active');
        });

        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-page') === page) {
                item.classList.add('active');
            }
        });

        // Show selected page
        const pageElement = document.getElementById(page + 'Page');
        if (pageElement) {
            pageElement.classList.add('active');

            // Load page data
            if (this.state.isLoggedIn) {
                this.loadPageData(page);
            }
        }
    }

    openSideNav() {
        document.getElementById('sideNav').classList.add('active');
        document.getElementById('sideNavOverlay').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeSideNav() {
        document.getElementById('sideNav').classList.remove('active');
        document.getElementById('sideNavOverlay').classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    openAuthModal(tab) {
        document.getElementById('authModal').classList.add('active');
        document.body.style.overflow = 'hidden';
        this.switchAuthTab(tab);
    }

    closeAuthModal() {
        document.getElementById('authModal').classList.remove('active');
        document.body.style.overflow = 'auto';
        this.resetRegistrationForm();
    }

    switchAuthTab(tab) {
        if (tab === 'login') {
            document.getElementById('loginTabBtn').classList.add('active');
            document.getElementById('registerTabBtn').classList.remove('active');
            document.getElementById('loginFormSection').classList.add('active');
            document.getElementById('registerFormSection').classList.remove('active');
            document.getElementById('modalTitle').textContent = 'Login to SheConnect';
        } else {
            document.getElementById('registerTabBtn').classList.add('active');
            document.getElementById('loginTabBtn').classList.remove('active');
            document.getElementById('registerFormSection').classList.add('active');
            document.getElementById('loginFormSection').classList.remove('active');
            document.getElementById('modalTitle').textContent = 'Join SheConnect';
            this.resetRegistrationForm();
        }
    }

    // ============ LOAD FROM LOCAL STORAGE ============

    loadFromLocalStorage() {
        try {
            const savedUser = localStorage.getItem('sheConnectUser');
            if (savedUser) {
                this.state.currentUser = JSON.parse(savedUser);
                this.state.isLoggedIn = true;
                this.updateUIForLoggedInUser();
                this.setupProfileImageUpload();
            }
        } catch (error) {
            console.error('Error loading from localStorage:', error);
        }
    }

    // ============ ENTREPRENEURS PAGE ============

    loadEntrepreneurs() {
        if (!this.state.isLoggedIn) return;

        const entrepreneursList = document.querySelector('.entrepreneurs-list');
        if (!entrepreneursList) return;

        entrepreneursList.innerHTML = '';

        // Filter by current category if not 'all'
        let filteredEntrepreneurs = this.state.entrepreneurs;
        if (this.state.currentCategory !== 'all') {
            filteredEntrepreneurs = this.state.entrepreneurs.filter(entrepreneur =>
                entrepreneur.category === this.state.currentCategory
            );
        }

        if (filteredEntrepreneurs.length === 0) {
            entrepreneursList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="empty-title">No entrepreneurs found</div>
                    <div class="empty-description">Try selecting a different category or search term</div>
                </div>
            `;
            return;
        }

        filteredEntrepreneurs.forEach(entrepreneur => {
            const card = document.createElement('div');
            card.className = 'entrepreneur-card';
            card.setAttribute('data-id', entrepreneur.id);

            let buttonHtml = '';

            if (entrepreneur.connectionStatus === 'accepted') {
                buttonHtml = `
                    <div class="connect-btn-container">
                        <button class="connect-btn connected" 
                                data-id="${entrepreneur.id}" 
                                data-name="${entrepreneur.name}"
                                data-type="entrepreneur">
                            Connected
                        </button>
                        <button class="chat-btn" 
                                data-id="${entrepreneur.id}" 
                                data-name="${entrepreneur.name}"
                                data-business="${entrepreneur.business_name}"
                                data-type="entrepreneur">
                            Chat Now
                        </button>
                    </div>
                `;
            } else if (entrepreneur.connectionStatus === 'pending') {
                buttonHtml = `
                    <button class="connect-btn requested" 
                            data-id="${entrepreneur.id}" 
                            data-name="${entrepreneur.name}"
                            data-type="entrepreneur"
                            disabled>
                        Requested
                    </button>
                `;
            } else {
                buttonHtml = `
                    <button class="connect-btn" 
                            data-id="${entrepreneur.id}" 
                            data-name="${entrepreneur.name}"
                            data-business="${entrepreneur.business_name}"
                            data-type="entrepreneur">
                        Connect
                    </button>
                `;
            }

            card.innerHTML = `
                <div class="entrepreneur-avatar">${entrepreneur.name.charAt(0).toUpperCase()}</div>
                <div class="entrepreneur-info">
                    <div class="entrepreneur-name">${entrepreneur.name}</div>
                    <div class="entrepreneur-business">${entrepreneur.business_name || ''}</div>
                    <div class="entrepreneur-location">
                        <i class="fas fa-map-marker-alt"></i> ${entrepreneur.location || 'Not Specified'}
                    </div>
                    ${entrepreneur.description ? `<div class="entrepreneur-description" style="font-size:12px;color:#666;margin-top:5px;">${entrepreneur.description.substring(0, 60)}${entrepreneur.description.length > 60 ? '...' : ''}</div>` : ''}
                    <div class="entrepreneur-rating" style="font-size:12px;color:#ffc107;margin-top:5px;">
                        <i class="fas fa-star"></i> ${entrepreneur.rating || '0.0'} (${entrepreneur.review_count || 0} reviews)
                    </div>
                </div>
                ${buttonHtml}
            `;

            entrepreneursList.appendChild(card);
        });

        // Add event listeners
        this.setupEntrepreneurEventListeners();
    }

    setupEntrepreneurEventListeners() {
        // Connect buttons
        document.querySelectorAll('.connect-btn:not(.connected):not(.requested)').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = btn.getAttribute('data-id');
                const entrepreneurName = btn.getAttribute('data-name');

                await this.handleConnectionRequest(id, entrepreneurName, btn);
            });
        });

        // Chat buttons
        document.querySelectorAll('.chat-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = btn.getAttribute('data-id');
                const entrepreneurName = btn.getAttribute('data-name');
                const entrepreneurBusiness = btn.getAttribute('data-business');
                const type = btn.getAttribute('data-type');

                await this.openChat(id, entrepreneurName, entrepreneurBusiness, type);
            });
        });
    }

    async handleConnectionRequest(entrepreneurId, entrepreneurName, button) {
        // Change button to "Sending Request..." state
        button.textContent = 'Sending Request...';
        button.classList.add('sending');
        button.disabled = true;

        this.showNotification(`Sending connection request to ${entrepreneurName}...`, 'info');

        // Save to Supabase
        const success = await this.saveConnectionToSupabase(entrepreneurId, `I'd like to connect with you!`);

        if (success) {
            // Update button state
            button.textContent = 'Requested';
            button.classList.remove('sending');
            button.classList.add('requested');

            this.showNotification(`Connection request sent to ${entrepreneurName}!`, 'success');

            // Update entrepreneur status in state
            const entrepreneurIndex = this.state.entrepreneurs.findIndex(e => e.id === entrepreneurId);
            if (entrepreneurIndex !== -1) {
                this.state.entrepreneurs[entrepreneurIndex].connectionStatus = 'pending';
            }
        } else {
            // Reset button on error
            button.textContent = 'Connect';
            button.classList.remove('sending');
            button.disabled = false;

            this.showNotification('Failed to send connection request. Please try again.', 'error');
        }
    }

    // ============ MESSAGES PAGE ============

    loadConversations() {
        if (!this.state.isLoggedIn) return;

        const messagesList = document.querySelector('.messages-list');
        if (!messagesList) return;

        messagesList.innerHTML = '';

        if (this.state.conversations.length === 0) {
            messagesList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="empty-title">No messages yet</div>
                    <div class="empty-description">Start connecting with entrepreneurs to receive messages</div>
                </div>
            `;
            return;
        }

        this.state.conversations.forEach(async (conversation) => {
            const card = document.createElement('div');
            card.className = `message-card ${conversation.unread_count > 0 ? 'unread' : ''}`;
            card.setAttribute('data-id', conversation.other_id);
            card.setAttribute('data-type', conversation.other_type);

            // Get other user's name
            const otherName = await this.getUserName(conversation.other_id);

            card.innerHTML = `
                <div class="message-avatar">${otherName.charAt(0).toUpperCase()}</div>
                <div class="message-info">
                    <div class="message-header">
                        <div class="message-sender">${otherName}</div>
                        <div class="message-time">${new Date(conversation.last_message_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                    </div>
                    <div class="message-preview">${conversation.last_message}</div>
                </div>
                ${conversation.unread_count > 0 ? `<div class="unread-badge">${conversation.unread_count}</div>` : ''}
            `;

            messagesList.appendChild(card);

            // Add click event
            card.addEventListener('click', async () => {
                const otherId = card.getAttribute('data-id');
                const otherType = card.getAttribute('data-type');
                const otherName = await this.getUserName(otherId);

                // Get business name if it's an entrepreneur
                let business = 'Business Owner';
                if (otherType === 'entrepreneur') {
                    const entrepreneur = this.state.entrepreneurs.find(e => e.id === otherId);
                    if (entrepreneur) {
                        business = entrepreneur.business_name;
                    }
                }

                this.openChat(otherId, otherName, business, otherType);
            });
        });
    }

    // ============ BUSINESS PROFILE PAGE ============

    updateBusinessProfile() {
        try {
            if (!this.state.currentUser) return;

            // Helper to safely set text
            const safeSetText = (id, text) => {
                const el = document.getElementById(id);
                if (el) el.textContent = text || '';
            };

            // Update business profile header
            if (this.state.currentUser.business_name) {
                safeSetText('businessAvatar', this.state.currentUser.business_name.charAt(0).toUpperCase());
            }

            safeSetText('businessNameDisplay', this.state.currentUser.business_name);
            safeSetText('businessCategoryDisplay', this.state.currentUser.business_category);

            // Update business info
            safeSetText('businessNameInfo', this.state.currentUser.business_name);
            safeSetText('businessCategoryInfo', this.state.currentUser.business_category);
            safeSetText('businessYearsInfo', `${this.state.currentUser.years_in_business || 1} years`);
            safeSetText('businessLocationInfo', this.state.currentUser.location);
            safeSetText('businessEmailInfo', this.state.currentUser.email);
            safeSetText('businessPhoneInfo', this.state.currentUser.phone);

            // Update business metrics display
            if (this.updateBusinessMetricsDisplay && typeof this.updateBusinessMetricsDisplay === 'function') {
                this.updateBusinessMetricsDisplay();
            }
        } catch (error) {
            console.warn('Error updating business profile UI:', error);
        }
    }

    loadUserProductsServices() {
        const productsGrid = document.getElementById('productsGrid');
        const servicesList = document.getElementById('servicesList');

        if (productsGrid) productsGrid.innerHTML = '';
        if (servicesList) servicesList.innerHTML = '';

        if (this.state.userProductsServices.length === 0) {
            if (productsGrid) {
                productsGrid.innerHTML = `
                    <div class="empty-state" style="grid-column: 1 / -1;">
                        <div class="empty-icon">
                            <i class="fas fa-box-open"></i>
                        </div>
                        <div class="empty-title">No Products/Services Added</div>
                        <div class="empty-description">Add your products or services to showcase your business</div>
                        <button class="form-btn" style="margin-top: 15px;" id="addFirstProduct">Add Your First Product/Service</button>
                    </div>
                `;

                const addFirstProductBtn = document.getElementById('addFirstProduct');
                if (addFirstProductBtn) {
                    addFirstProductBtn.addEventListener('click', () => this.openProductForm());
                }
            }
            return;
        }

        // Separate products and services
        const products = this.state.userProductsServices.filter(item => item.type === 'product');
        const services = this.state.userProductsServices.filter(item => item.type === 'service');

        // Display products
        if (productsGrid && products.length > 0) {
            products.forEach(product => {
                const productCard = document.createElement('div');
                productCard.className = 'product-card';
                productCard.innerHTML = `
                    <div class="product-image">
                        ${product.images && product.images.length > 0 ?
                        `<img src="${product.images[0]}" alt="${product.name}">` :
                        `<i class="fas fa-box"></i>`}
                        <div class="product-actions">
                            <button class="product-action-btn edit-product" data-id="${product.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="product-action-btn delete-product" data-id="${product.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    <div class="product-info">
                        <div class="product-name">${product.name}</div>
                        <div class="product-price">₹${product.price}</div>
                    </div>
                `;
                productsGrid.appendChild(productCard);
            });
        }

        // Display services
        if (servicesList && services.length > 0) {
            services.forEach(service => {
                const serviceItem = document.createElement('div');
                serviceItem.className = 'service-item';
                serviceItem.innerHTML = `
                    <div class="service-icon">
                        <i class="fas fa-handshake"></i>
                    </div>
                    <div class="service-details">
                        <h4>${service.name}</h4>
                        <p>${service.description.substring(0, 80)}${service.description.length > 80 ? '...' : ''}</p>
                        <div class="service-price" style="color: #9c3587; font-weight: 500; margin-top: 5px;">₹${service.price}</div>
                    </div>
                    <div class="product-actions">
                        <button class="product-action-btn edit-product" data-id="${service.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="product-action-btn delete-product" data-id="${service.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                `;
                servicesList.appendChild(serviceItem);
            });
        }

        // Add event listeners to product/service actions
        document.querySelectorAll('.edit-product').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                this.editProductService(id);
            });
        });

        document.querySelectorAll('.delete-product').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.getAttribute('data-id');
                this.deleteProductService(id);
            });
        });
    }

    // ============ CHAT FUNCTIONALITY ============

    setupChat() {
        this.state.chatMessages = [];
    }

    async openChat(otherId, otherName, otherBusiness, otherType) {
        this.state.currentChatWith = {
            id: otherId,
            name: otherName,
            business: otherBusiness,
            type: otherType
        };

        // Update chat header
        document.getElementById('chatUserAvatar').textContent = otherName.charAt(0).toUpperCase();
        document.getElementById('chatUserName').textContent = otherName;
        document.getElementById('chatUserBusiness').textContent = otherBusiness;

        // Load chat history
        await this.loadChatHistory(otherId);

        // Open chat modal
        document.getElementById('chatModal').classList.add('active');
        document.body.style.overflow = 'hidden';

        // Focus on input
        setTimeout(() => {
            document.getElementById('chatInput').focus();
        }, 300);

        this.showNotification(`Chat opened with ${otherName}`, 'info');
    }

    async loadChatHistory(otherId) {
        if (!this.supabase || !this.state.currentUser) return;

        try {
            // Generate conversation ID
            const conversationId = this.state.currentUser.id < otherId ?
                `${this.state.currentUser.id}_${otherId}` :
                `${otherId}_${this.state.currentUser.id}`;

            // Load messages for this conversation
            const { data: messages, error } = await this.supabase
                .from('chat_messages')
                .select('*')
                .eq('conversation_id', conversationId)
                .order('created_at', { ascending: true });

            if (!error && messages) {
                this.state.chatMessages = messages;
                this.renderChatMessages();

                // Mark messages as read
                const unreadMessages = messages.filter(msg =>
                    msg.receiver_id === this.state.currentUser.id && !msg.is_read
                );

                for (const msg of unreadMessages) {
                    await this.supabase
                        .from('chat_messages')
                        .update({ is_read: true, read_at: new Date().toISOString() })
                        .eq('id', msg.id);
                }
            }
        } catch (error) {
            console.error('Error loading chat history:', error);
        }
    }

    async sendMessage() {
        const input = document.getElementById('chatInput');
        const messageText = input.value.trim();

        if (!messageText || !this.state.currentChatWith) return;

        // Save to Supabase
        const savedMessage = await this.saveChatMessageToSupabase(
            messageText,
            this.state.currentChatWith.id,
            this.state.currentChatWith.type
        );

        if (savedMessage) {
            // Add to local state
            this.state.chatMessages.push(savedMessage);
            this.renderChatMessages();
            input.value = '';

            // Update conversations list
            await this.loadConversationsFromSupabase();
        }
    }

    renderChatMessages() {
        const chatMessagesDiv = document.getElementById('chatMessages');
        if (!chatMessagesDiv) return;

        chatMessagesDiv.innerHTML = '';

        // Group messages by date
        const messagesByDate = {};
        this.state.chatMessages.forEach(msg => {
            const date = new Date(msg.created_at).toLocaleDateString();
            if (!messagesByDate[date]) {
                messagesByDate[date] = [];
            }
            messagesByDate[date].push(msg);
        });

        // Render messages
        Object.keys(messagesByDate).forEach(date => {
            // Add date separator
            chatMessagesDiv.innerHTML += `<div class="date-separator"><span>${date}</span></div>`;

            // Add messages for this date
            messagesByDate[date].forEach(msg => {
                const isMe = msg.sender_id === this.state.currentUser.id;
                const time = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

                chatMessagesDiv.innerHTML += `
                    <div class="message ${isMe ? 'sent' : 'received'}">
                        <div class="message-text">${msg.message}</div>
                        <div class="message-time">
                            ${time}
                            ${isMe ?
                        `<span class="message-status">
                                    <i class="fas fa-${msg.is_read ? 'check-double' : 'check'}"></i>
                                </span>` : ''}
                        </div>
                    </div>
                `;
            });
        });

        chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;
    }

    closeChat() {
        document.getElementById('chatModal').classList.remove('active');
        document.body.style.overflow = 'auto';
        this.state.currentChatWith = null;
        this.state.chatMessages = [];
        document.getElementById('chatInput').value = '';

        this.showNotification('Chat ended successfully', 'info');
    }

    // ============ PRODUCT FORM ============

    openProductForm() {
        document.getElementById('productFormModal').classList.add('active');
        document.body.style.overflow = 'hidden';
        // Reset form
        document.getElementById('productServiceForm').reset();
        document.getElementById('mediaPreviewContainer').innerHTML = '';
        this.state.uploadedMedia = [];
    }

    closeProductForm() {
        document.getElementById('productFormModal').classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    async handleProductServiceSubmit() {
        const itemType = document.getElementById('itemType').value;
        const itemName = document.getElementById('itemName').value;
        const itemDescription = document.getElementById('itemDescription').value;
        const itemPrice = document.getElementById('itemPrice').value;
        const itemCategory = document.getElementById('itemCategory').value;
        const availableForCollab = document.getElementById('availableForCollab').checked;

        if (!itemName || !itemDescription || !itemPrice) {
            this.showNotification('Please fill in all required fields', 'error');
            return;
        }

        const productData = {
            name: itemName,
            description: itemDescription,
            price: parseFloat(itemPrice),
            type: itemType,
            category: itemCategory || this.state.currentUser.business_category,
            available_for_collab: availableForCollab
        };

        // Save to Supabase
        const savedProduct = await this.saveProductToSupabase(productData);

        if (savedProduct) {
            this.showNotification(`${itemType === 'product' ? 'Product' : 'Service'} added successfully!`, 'success');

            // Close form and reload display
            this.closeProductForm();
            await this.loadProductsFromSupabase();
            this.loadUserProductsServices();

            // Update business metrics
            this.state.businessMetrics.active_projects += 1;
            this.updateBusinessMetricsDisplay();
        } else {
            this.showNotification('Failed to save product/service. Please try again.', 'error');
        }
    }

    async editProductService(id) {
        const item = this.state.userProductsServices.find(item => item.id === id);
        if (!item) return;

        this.showNotification('Edit feature coming soon!', 'info');
    }

    async deleteProductService(id) {
        if (confirm('Are you sure you want to delete this item?')) {
            // Delete from Supabase
            const success = await this.deleteProductFromSupabase(id);

            if (success) {
                // Reload products
                await this.loadProductsFromSupabase();
                this.loadUserProductsServices();

                this.showNotification('Item deleted successfully', 'success');
            } else {
                this.showNotification('Failed to delete item. Please try again.', 'error');
            }
        }
    }

    // ============ OTHER FUNCTIONALITIES ============

    handleFilterClick(filter, button) {
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        button.classList.add('active');

        this.filterEntrepreneursByCategory(filter);

        this.state.currentCategory = filter;
    }

    filterEntrepreneursByCategory(category) {
        this.state.currentCategory = category;
        this.loadEntrepreneurs();
    }

    filterEntrepreneursBySearch(searchTerm) {
        const entrepreneurs = document.querySelectorAll('.entrepreneur-card');

        if (!searchTerm) {
            // If search is empty, show all based on current category
            this.loadEntrepreneurs();
            return;
        }

        entrepreneurs.forEach(card => {
            const name = card.querySelector('.entrepreneur-name').textContent.toLowerCase();
            const business = card.querySelector('.entrepreneur-business').textContent.toLowerCase();

            if (name.includes(searchTerm.toLowerCase()) || business.includes(searchTerm.toLowerCase())) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    }

    // Call methods
    initiateCall(type) {
        if (!this.state.currentChatWith) return;

        this.state.isCallActive = true;
        document.getElementById('callUserAvatar').textContent = this.state.currentChatWith.name.charAt(0).toUpperCase();
        document.getElementById('callUserName').textContent = this.state.currentChatWith.name;
        document.getElementById('callStatus').textContent = type === 'audio' ? 'Audio call connecting...' : 'Video call connecting...';

        document.getElementById('callInterface').classList.add('active');
        document.body.style.overflow = 'hidden';

        // Simulate call ringing
        setTimeout(() => {
            if (this.state.isCallActive) {
                document.getElementById('callStatus').textContent = type === 'audio' ? 'Audio call in progress...' : 'Video call in progress...';
                this.showNotification(`${type === 'audio' ? 'Audio' : 'Video'} call started with ${this.state.currentChatWith.name}`, 'info');
            }
        }, 2000);
    }

    acceptCall() {
        document.getElementById('callStatus').textContent = 'Call connected';
        this.showNotification('Call accepted', 'success');
    }

    rejectCall() {
        this.endCall();
        this.showNotification('Call rejected', 'info');
    }

    endCall() {
        document.getElementById('callInterface').classList.remove('active');
        document.body.style.overflow = 'auto';
        this.state.isCallActive = false;
        this.showNotification('Call ended', 'info');
    }

    // Meeting methods
    async initiateMeeting(platform) {
        if (!this.state.currentChatWith) return;

        const platforms = {
            'google-meet': { name: 'Google Meet', url: 'https://meet.google.com' },
            'zoom': { name: 'Zoom', url: 'https://zoom.us' },
            'teams': { name: 'Microsoft Teams', url: 'https://teams.microsoft.com' }
        };

        const selectedPlatform = platforms[platform];
        const meetingId = `sheconnect-${Date.now().toString().slice(-8)}`;
        const meetingUrl = `${selectedPlatform.url}/join/${meetingId}`;

        // Create meeting in Supabase
        const meetingData = {
            title: `Meeting with ${this.state.currentChatWith.name}`,
            description: `Business discussion meeting`,
            participant_id: this.state.currentChatWith.id,
            meeting_type: 'video',
            platform: platform.replace('-', '_'),
            meeting_link: meetingUrl,
            scheduled_for: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow
            duration_minutes: 30,
            agenda: 'Discuss business collaboration opportunities'
        };

        const meeting = await this.createMeeting(meetingData);

        if (meeting) {
            // Add meeting link to chat
            await this.saveChatMessageToSupabase(
                `I've scheduled a ${selectedPlatform.name} meeting. Meeting ID: ${meetingId}\nJoin here: ${meetingUrl}`,
                this.state.currentChatWith.id,
                this.state.currentChatWith.type
            );

            this.showNotification(`${selectedPlatform.name} meeting scheduled`, 'success');

            // Update business metrics
            this.state.businessMetrics.collaborations_count += 1;
            this.updateBusinessMetricsDisplay();
        }
    }

    // Payment methods
    openPaymentInterface() {
        document.getElementById('paymentInterface').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closePaymentInterface() {
        document.getElementById('paymentInterface').classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    selectPaymentMethod(method) {
        document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
        method.classList.add('selected');
    }

    async processPayment() {
        const selectedMethod = document.querySelector('.payment-method.selected');
        if (!selectedMethod) {
            this.showNotification('Please select a payment method', 'error');
            return;
        }

        const methodName = selectedMethod.querySelector('h3').textContent;
        const methodValue = selectedMethod.getAttribute('data-method');

        // Simulate payment processing
        this.showNotification(`Processing ${methodName}...`, 'info');

        setTimeout(async () => {
            this.closePaymentInterface();

            // Create payment record (in a real app, this would integrate with a payment gateway)
            const paymentData = {
                order_id: null, // You would need an order ID here
                receiver_id: this.state.currentChatWith?.id,
                amount: 5000.00,
                payment_method: methodValue,
                payment_gateway: methodValue === 'upi' ? 'razorpay' : 'stripe',
                description: `Payment to ${this.state.currentChatWith?.name}`,
                metadata: { note: 'Business transaction' }
            };

            const payment = await this.createPayment(paymentData);

            if (payment) {
                // Add payment confirmation to chat
                await this.saveChatMessageToSupabase(
                    `Payment of ₹5,000.00 completed via ${methodName}`,
                    this.state.currentChatWith.id,
                    this.state.currentChatWith.type
                );

                this.showNotification('Payment successful!', 'success');

                // Update business metrics
                this.state.businessMetrics.total_revenue += 5000;
                this.state.businessMetrics.monthly_revenue += 5000 / 12;
                this.state.businessMetrics.order_volume += 1;
                this.updateBusinessMetricsDisplay();
            }
        }, 2000);
    }

    // Order methods
    async placeOrder() {
        if (!this.state.currentChatWith) return;

        // Find a product/service to order
        const products = this.state.userProductsServices.filter(item => item.type === 'product');
        if (products.length === 0) {
            this.showNotification('No products available to order', 'error');
            return;
        }

        const product = products[0];
        const quantity = 1;
        const totalAmount = product.price * quantity;

        // Create order
        const orderData = {
            seller_id: this.state.currentUser.id, // In real scenario, this would be the seller's ID
            product_service_id: product.id,
            unit_price: product.price,
            total_amount: totalAmount,
            shipping_address: {
                name: this.state.currentUser.full_name,
                address: this.state.currentUser.location,
                phone: this.state.currentUser.phone
            },
            notes: 'Order placed via chat'
        };

        const order = await this.createOrder(orderData);

        if (order) {
            // Add order message to chat
            await this.saveChatMessageToSupabase(
                `Order placed: ${product.name}\nQuantity: ${quantity}\nTotal: ₹${totalAmount}`,
                this.state.currentChatWith.id,
                this.state.currentChatWith.type
            );

            this.showNotification('Order placed successfully!', 'success');
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for supabase-config.js to load
    setTimeout(() => {
        window.sheConnectApp = new SheConnectApp();
    }, 100);
});
