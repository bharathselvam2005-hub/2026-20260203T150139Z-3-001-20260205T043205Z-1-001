// www/auto-update.js - Auto-update system for SheConnect
console.log('🚀 SheConnect App Loaded');

class SheConnectUpdater {
  constructor() {
    this.updateInterval = 20000; // Check every 20 seconds
    this.isDevelopment = window.location.hostname === '192.168.7.113';
    this.updateBtn = null;
  }

  init() {
    console.log('🔄 AutoUpdater initialized');
    
    // Check immediately
    setTimeout(() => this.checkForUpdates(), 3000);
    
    // Check periodically
    setInterval(() => this.checkForUpdates(), this.updateInterval);
    
    // Check when app comes to foreground
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) this.checkForUpdates();
    });
    
    // Add manual refresh button for development
    if (this.isDevelopment) {
      this.addManualRefreshButton();
    }
  }

  async checkForUpdates() {
    if (!this.isDevelopment) return;
    
    try {
      const response = await fetch(`/?_t=${Date.now()}`, {
        method: 'HEAD',
        cache: 'no-store'
      });
      
      // If we got here, server is running
      this.showUpdateAvailable();
      
    } catch (error) {
      console.log('📡 Server offline');
      this.hideUpdateButton();
    }
  }

  showUpdateAvailable() {
    if (!this.isDevelopment || !this.updateBtn) return;
    
    this.updateBtn.style.display = 'block';
    this.updateBtn.innerHTML = '🔄 Update Available';
    this.updateBtn.style.background = '#4CAF50';
  }

  hideUpdateButton() {
    if (this.updateBtn) {
      this.updateBtn.style.display = 'none';
    }
  }

  addManualRefreshButton() {
    // Remove existing button
    const existing = document.getElementById('dev-refresh-btn');
    if (existing) existing.remove();
    
    // Create floating button
    this.updateBtn = document.createElement('button');
    this.updateBtn.id = 'dev-refresh-btn';
    this.updateBtn.innerHTML = '🔄 Dev Mode';
    this.updateBtn.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #2196F3;
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 20px;
      z-index: 9999;
      cursor: pointer;
      box-shadow: 0 2px 10px rgba(0,0,0,0.2);
      font-family: Arial, sans-serif;
      font-size: 14px;
      display: none;
    `;
    
    this.updateBtn.onclick = () => {
      this.updateBtn.innerHTML = '🔄 Reloading...';
      this.updateBtn.disabled = true;
      setTimeout(() => {
        window.location.reload(true);
      }, 500);
    };
    
    document.body.appendChild(this.updateBtn);
  }
}

// Start updater when page loads
document.addEventListener('DOMContentLoaded', () => {
  window.sheConnectUpdater = new SheConnectUpdater();
  window.sheConnectUpdater.init();
});