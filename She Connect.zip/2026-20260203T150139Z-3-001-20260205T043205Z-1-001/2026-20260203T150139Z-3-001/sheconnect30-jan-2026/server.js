const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Serve static files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// API routes for future backend functionality
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'SheConnect server is running' });
});

// Handle all other routes by serving index.html (for SPA-like behavior)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 SheConnect B2B Marketplace running on http://localhost:${PORT}`);
    console.log(`📱 Mobile-responsive women's business networking platform`);
});
