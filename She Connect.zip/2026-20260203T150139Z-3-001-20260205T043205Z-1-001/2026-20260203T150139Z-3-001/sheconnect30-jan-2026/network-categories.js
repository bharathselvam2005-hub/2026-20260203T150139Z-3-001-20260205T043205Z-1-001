// network-categories.js
class NetworkCategories {
    constructor() {
        this.networkData = {
            usersByCategory: {
                fashion: [],
                food: [],
                beauty: [],
                handmade: [],
                consulting: [],
                education: [],
                tech: [],
                healthcare: [],
                other: []
            },
            allUsers: [],
            currentUserCategory: null,
            userConnections: {},
            connectionRequests: {}
        };

        this.initializeNetwork();
    }

    initializeNetwork() {
        this.loadNetworkData();
        this.setupEventListeners();
        this.populateSampleData();
        this.updateNetworkDisplay();
    }

    setupEventListeners() {
        // Category filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const filter = e.target.dataset.filter;
                this.filterNetworkByCategory(filter);
            });
        });

        // Category navigation in side nav
        document.querySelectorAll('.side-nav-categories .category-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const category = e.currentTarget.dataset.category;
                if (category) {
                    this.filterNetworkByCategory(category);
                    // Switch to networking page
                    showPage('networking');
                }
            });
        });

        // Connect buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('.connect-btn')) {
                const btn = e.target.closest('.connect-btn');
                const userId = btn.dataset.userId;
                this.handleConnectionRequest(userId, btn);
            }
        });

        // Search functionality
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchNetwork(e.target.value);
            });
        }
    }

    loadNetworkData() {
        const savedData = localStorage.getItem('sheconnect_network_data_v2');
        if (savedData) {
            this.networkData = JSON.parse(savedData);
        }

        // Load current user's category
        const currentUser = JSON.parse(localStorage.getItem('sheconnect_current_user'));
        if (currentUser && currentUser.businessCategory) {
            this.currentUserCategory = currentUser.businessCategory;
        }
    }

    saveNetworkData() {
        localStorage.setItem('sheconnect_network_data_v2', JSON.stringify(this.networkData));
    }

    populateSampleData() {
        // No sample data needed
    }

    generateSampleUsers() {
        return [];
    }


    categorizeAllUsers() {
        // Clear existing categorization
        Object.keys(this.networkData.usersByCategory).forEach(category => {
            this.networkData.usersByCategory[category] = [];
        });

        // Categorize each user
        this.networkData.allUsers.forEach(user => {
            const category = user.category || 'other';
            if (this.networkData.usersByCategory[category]) {
                this.networkData.usersByCategory[category].push(user);
            } else {
                this.networkData.usersByCategory.other.push(user);
            }
        });
    }

    filterNetworkByCategory(category) {
        // Update active filter button
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.filter === category) {
                btn.classList.add('active');
            }
        });

        // Update active category in side nav
        document.querySelectorAll('.side-nav-categories .category-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.category === category) {
                item.classList.add('active');
            }
        });

        // Display users for selected category
        this.displayUsersByCategory(category);
    }

    displayUsersByCategory(category) {
        const entrepreneursList = document.querySelector('.entrepreneurs-list');
        if (!entrepreneursList) return;

        // Get users for the selected category
        let users = [];
        if (category === 'all') {
            // Show all users
            users = [...this.networkData.allUsers];
        } else {
            users = [...(this.networkData.usersByCategory[category] || [])];
        }

        // Remove current user from the list
        const currentUser = JSON.parse(localStorage.getItem('sheconnect_current_user'));
        if (currentUser) {
            users = users.filter(user => user.id !== currentUser.id);
        }

        // Generate HTML for each user
        entrepreneursList.innerHTML = '';

        if (users.length === 0) {
            entrepreneursList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="empty-title">No Entrepreneurs Found</h3>
                    <p class="empty-description">No entrepreneurs found in this category. Try another category or check back later.</p>
                </div>
            `;
            return;
        }

        users.forEach(user => {
            const connectionStatus = this.getConnectionStatus(user.id);
            const connectBtnClass = this.getConnectButtonClass(connectionStatus);
            const connectBtnText = this.getConnectButtonText(connectionStatus);

            const entrepreneurCard = document.createElement('div');
            entrepreneurCard.className = 'entrepreneur-card';
            entrepreneurCard.innerHTML = `
                <div class="entrepreneur-avatar">${user.avatar}</div>
                <div class="entrepreneur-info">
                    <div class="entrepreneur-name">${user.name}</div>
                    <div class="entrepreneur-business">${user.business}</div>
                    <div class="entrepreneur-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${user.location}
                    </div>
                    <div class="entrepreneur-stats" style="margin-top: 8px; font-size: 12px; color: #666;">
                        <span style="margin-right: 15px;"><i class="fas fa-star" style="color: #FFD700;"></i> ${user.rating}/5</span>
                        <span><i class="fas fa-users"></i> ${user.connections} connections</span>
                    </div>
                </div>
                <div class="connect-btn-container">
                    <button class="connect-btn ${connectBtnClass}" data-user-id="${user.id}">
                        ${connectBtnText}
                    </button>
                    ${connectionStatus === 'connected' ?
                    `<button class="chat-btn" data-user-id="${user.id}" onclick="openChatWithUser('${user.id}')">
                            <i class="fas fa-comment"></i> Chat
                        </button>` :
                    ''
                }
                </div>
            `;

            entrepreneursList.appendChild(entrepreneurCard);
        });
    }

    getConnectionStatus(userId) {
        const currentUser = JSON.parse(localStorage.getItem('sheconnect_current_user'));
        if (!currentUser) return 'connect';

        // Check if already connected
        if (this.networkData.userConnections[currentUser.id]) {
            if (this.networkData.userConnections[currentUser.id].includes(userId)) {
                return 'connected';
            }
        }

        // Check if request sent
        if (this.networkData.connectionRequests[currentUser.id]) {
            if (this.networkData.connectionRequests[currentUser.id].sent.includes(userId)) {
                return 'requested';
            }
        }

        return 'connect';
    }

    getConnectButtonClass(status) {
        switch (status) {
            case 'connected': return 'connected';
            case 'requested': return 'requested';
            case 'sending': return 'sending';
            default: return '';
        }
    }

    getConnectButtonText(status) {
        switch (status) {
            case 'connected': return '<i class="fas fa-check"></i> Connected';
            case 'requested': return '<i class="fas fa-clock"></i> Request Sent';
            case 'sending': return '<i class="fas fa-spinner fa-spin"></i> Sending...';
            default: return '<i class="fas fa-user-plus"></i> Connect';
        }
    }

    handleConnectionRequest(userId, button) {
        const currentUser = JSON.parse(localStorage.getItem('sheconnect_current_user'));

        if (!currentUser) {
            showNotification('Please login to connect with other entrepreneurs', 'error');
            return;
        }

        // Update button to show sending state
        button.classList.add('sending');
        button.innerHTML = this.getConnectButtonText('sending');

        // Simulate API call delay
        setTimeout(() => {
            // Initialize connection requests if not exists
            if (!this.networkData.connectionRequests[currentUser.id]) {
                this.networkData.connectionRequests[currentUser.id] = {
                    sent: [],
                    received: []
                };
            }

            // Add connection request
            if (!this.networkData.connectionRequests[currentUser.id].sent.includes(userId)) {
                this.networkData.connectionRequests[currentUser.id].sent.push(userId);

                // Initialize receiver's request list if not exists
                if (!this.networkData.connectionRequests[userId]) {
                    this.networkData.connectionRequests[userId] = {
                        sent: [],
                        received: []
                    };
                }

                this.networkData.connectionRequests[userId].received.push(currentUser.id);
                this.saveNetworkData();

                // Update button to requested state
                button.classList.remove('sending');
                button.classList.add('requested');
                button.innerHTML = this.getConnectButtonText('requested');

                showNotification('Connection request sent successfully!', 'success');
            }
        }, 1500);
    }

    searchNetwork(searchTerm) {
        if (!searchTerm.trim()) {
            // If search is empty, show current category
            const activeFilter = document.querySelector('.filter-btn.active');
            const category = activeFilter ? activeFilter.dataset.filter : 'all';
            this.displayUsersByCategory(category);
            return;
        }

        const entrepreneursList = document.querySelector('.entrepreneurs-list');
        if (!entrepreneursList) return;

        const searchLower = searchTerm.toLowerCase();
        const currentUser = JSON.parse(localStorage.getItem('sheconnect_current_user'));

        // Search across all users
        const filteredUsers = this.networkData.allUsers.filter(user => {
            if (currentUser && user.id === currentUser.id) return false;

            return user.name.toLowerCase().includes(searchLower) ||
                user.business.toLowerCase().includes(searchLower) ||
                user.description.toLowerCase().includes(searchLower) ||
                user.category.toLowerCase().includes(searchLower) ||
                user.location.toLowerCase().includes(searchLower) ||
                user.products.some(product => product.toLowerCase().includes(searchLower));
        });

        // Display filtered users
        entrepreneursList.innerHTML = '';

        if (filteredUsers.length === 0) {
            entrepreneursList.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3 class="empty-title">No Results Found</h3>
                    <p class="empty-description">No entrepreneurs match your search. Try different keywords.</p>
                </div>
            `;
            return;
        }

        filteredUsers.forEach(user => {
            const connectionStatus = this.getConnectionStatus(user.id);
            const connectBtnClass = this.getConnectButtonClass(connectionStatus);
            const connectBtnText = this.getConnectButtonText(connectionStatus);

            const entrepreneurCard = document.createElement('div');
            entrepreneurCard.className = 'entrepreneur-card';
            entrepreneurCard.innerHTML = `
                <div class="entrepreneur-avatar">${user.avatar}</div>
                <div class="entrepreneur-info">
                    <div class="entrepreneur-name">${user.name}</div>
                    <div class="entrepreneur-business">${user.business}</div>
                    <div class="entrepreneur-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${user.location}
                    </div>
                    <div style="font-size: 12px; color: #9c3587; margin-top: 5px;">
                        <i class="fas fa-tag"></i> ${this.getCategoryName(user.category)}
                    </div>
                    <div class="entrepreneur-stats" style="margin-top: 8px; font-size: 12px; color: #666;">
                        <span style="margin-right: 15px;"><i class="fas fa-star" style="color: #FFD700;"></i> ${user.rating}/5</span>
                        <span><i class="fas fa-users"></i> ${user.connections} connections</span>
                    </div>
                </div>
                <div class="connect-btn-container">
                    <button class="connect-btn ${connectBtnClass}" data-user-id="${user.id}">
                        ${connectBtnText}
                    </button>
                    ${connectionStatus === 'connected' ?
                    `<button class="chat-btn" data-user-id="${user.id}" onclick="openChatWithUser('${user.id}')">
                            <i class="fas fa-comment"></i> Chat
                        </button>` :
                    ''
                }
                </div>
            `;

            entrepreneursList.appendChild(entrepreneurCard);
        });
    }

    getCategoryName(category) {
        const categoryMap = {
            'fashion': 'Fashion & Apparel',
            'food': 'Food & Beverages',
            'beauty': 'Beauty & Wellness',
            'handmade': 'Handmade Products',
            'consulting': 'Consulting Services',
            'education': 'Education & Training',
            'tech': 'Technology Services',
            'healthcare': 'Healthcare Services',
            'other': 'Other Categories'
        };

        return categoryMap[category] || 'Other';
    }

    updateNetworkDisplay() {
        // If on networking page, display initial data
        if (document.getElementById('networkingPage').classList.contains('active')) {
            this.displayUsersByCategory('all');
        }
    }

    addNewUser(userData) {
        // Generate unique ID
        const userId = 'user_' + Date.now();
        userData.id = userId;

        // Add to all users
        this.networkData.allUsers.push(userData);

        // Categorize the user
        const category = userData.category || 'other';
        if (this.networkData.usersByCategory[category]) {
            this.networkData.usersByCategory[category].push(userData);
        } else {
            this.networkData.usersByCategory.other.push(userData);
        }

        // Save updated data
        this.saveNetworkData();

        return userId;
    }

    getUserById(userId) {
        return this.networkData.allUsers.find(user => user.id === userId);
    }

    getUsersByCategory(category) {
        return this.networkData.usersByCategory[category] || [];
    }

    getAllCategories() {
        return Object.keys(this.networkData.usersByCategory);
    }

    setUsers(users) {
        console.log('Updating network with ' + users.length + ' users');
        this.networkData.allUsers = users;
        this.categorizeAllUsers();
        this.updateNetworkDisplay();
    }

    getCategoryStats() {
        const stats = {};
        Object.keys(this.networkData.usersByCategory).forEach(category => {
            stats[category] = this.networkData.usersByCategory[category].length;
        });
        return stats;
    }
}

// Initialize network categories globally
let networkCategories;

// Function to open chat with user
function openChatWithUser(userId) {
    const user = networkCategories.getUserById(userId);
    if (user) {
        openChatModal(user);
    }
}

// Function to show notification
function showNotification(message, type = 'success') {
    // Use global notification if available
    if (window.sheConnectApp && window.sheConnectApp.showNotification) {
        window.sheConnectApp.showNotification(message, type);
        return;
    }

    const notification = document.getElementById('notification');
    if (notification) {
        notification.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
        notification.className = `notification show ${type}`;

        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
}

// Function to show page
function showPage(pageId) {
    document.querySelectorAll('.page-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(pageId + 'Page').classList.add('active');

    // Update bottom nav
    document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === pageId) {
            item.classList.add('active');
        }
    });

    // Update network display if on networking page
    if (pageId === 'networking' && networkCategories) {
        networkCategories.updateNetworkDisplay();
    }
}

// Function to open chat modal
function openChatModal(user) {
    document.getElementById('chatUserName').textContent = user.name;
    document.getElementById('chatUserBusiness').textContent = user.business;
    document.getElementById('chatUserAvatar').textContent = user.avatar;

    const chatModal = document.getElementById('chatModal');
    chatModal.classList.add('active');

    // Populate chat messages
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = `
        <div class="date-separator">
            <span>Today</span>
        </div>
        <div class="message received">
            <div class="message-text">Hi! I'm interested in your ${user.products && user.products.length > 0 ? user.products[0] : 'services'}. Can we discuss collaboration possibilities?</div>
            <div class="message-time">10:30 AM <span class="message-status">✓✓</span></div>
        </div>
        <div class="message sent">
            <div class="message-text">Hello! I'd love to discuss collaboration opportunities. What do you have in mind?</div>
            <div class="message-time">10:32 AM <span class="message-status">✓✓</span></div>
        </div>
        <div class="typing-indicator" id="typingIndicator" style="display: none;">
            <div class="typing-dots">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
            <span>${user.name.split(' ')[0]} is typing...</span>
        </div>
    `;
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function () {
    networkCategories = new NetworkCategories();

    // Add event listeners for bottom nav
    document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            const pageId = this.dataset.page;
            showPage(pageId);
        });
    });

    // Add event listeners for side nav page links
    document.querySelectorAll('.side-nav-categories .category-item[data-page]').forEach(item => {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            const pageId = this.dataset.page;
            showPage(pageId);

            // Close side nav
            document.getElementById('sideNav').classList.remove('active');
            document.getElementById('sideNavOverlay').classList.remove('active');
        });
    });
});
